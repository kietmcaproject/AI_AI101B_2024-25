# Install required libraries
!pip install SpeechRecognition
!pip install pydub
!pip install ffmpeg-python
import speech_recognition as sr
from pydub import AudioSegment
from pydub.playback import play
import os
from google.colab import files
import IPython.display as ipd

# Upload audio
print("👉 Please upload your audio file (WAV/MP3):")
uploaded_audio = files.upload()

# Get filename
for file_name in uploaded_audio.keys():
    audio_file = file_name

# Play audio
print("🎧 Playing your audio file...")
ipd.display(ipd.Audio(audio_file))
import speech_recognition as sr
import os
from pydub import AudioSegment

# Convert mp3 to wav (speech recognition supports wav)
sound = AudioSegment.from_mp3(audio_file)
wav_file = "converted.wav"
sound.export(wav_file, format="wav")

# Initialize recognizer
recognizer = sr.Recognizer()

# Load the audio file
with sr.AudioFile(wav_file) as source:
    audio_data = recognizer.record(source)
    try:
        text = recognizer.recognize_google(audio_data)
        print("📝 Transcribed Text:")
        print(text)
    except sr.UnknownValueError:
        print("❌ Sorry, could not understand the audio.")
    except sr.RequestError:
        print("⚠ Could not request results from Google Speech Recognition service.")