from flask import Flask, render_template, request, jsonify
from transformers import BlenderbotTokenizer, BlenderbotForConditionalGeneration

app = Flask(__name__)

# Load model and tokenizer
model_name = "facebook/blenderbot-400M-distill"
tokenizer = BlenderbotTokenizer.from_pretrained(model_name)
model = BlenderbotForConditionalGeneration.from_pretrained(model_name)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chat():
    user_msg = request.form["msg"]
    inputs = tokenizer([user_msg], return_tensors="pt")
    reply_ids = model.generate(**inputs)
    bot_response = tokenizer.batch_decode(reply_ids, skip_special_tokens=True)[0]
    return jsonify({"response": bot_response})

if __name__ == "__main__":
    app.run(debug=True)