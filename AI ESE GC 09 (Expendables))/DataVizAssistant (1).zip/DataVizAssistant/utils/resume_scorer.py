import re
from datetime import datetime
import math

class ResumeScorer:
    """Comprehensive resume scoring system"""
    
    def __init__(self):
        self.scoring_weights = {
            'skills_match': 0.30,
            'experience': 0.25,
            'education': 0.20,
            'keyword_relevance': 0.15,
            'format_quality': 0.10
        }
    
    def score_resume(self, resume_text, job_description, classification_result, nlp_analysis):
        """Calculate comprehensive resume score"""
        scores = {}
        
        # Skills matching score
        scores['skills_score'] = self._calculate_skills_score(
            nlp_analysis.get('skills', []), 
            job_description,
            classification_result
        )
        
        # Experience score
        scores['experience_score'] = self._calculate_experience_score(
            nlp_analysis.get('experience', {}),
            resume_text
        )
        
        # Education score
        scores['education_score'] = self._calculate_education_score(
            nlp_analysis.get('education', []),
            resume_text
        )
        
        # Keyword relevance score
        scores['keyword_score'] = self._calculate_keyword_score(
            nlp_analysis.get('keywords', []),
            job_description,
            resume_text
        )
        
        # Format and presentation score
        scores['format_score'] = self._calculate_format_score(
            resume_text,
            nlp_analysis
        )
        
        # Calculate overall weighted score
        overall_score = sum(
            scores[key.replace('_score', '') + '_score'] * self.scoring_weights[key.replace('_score', '')]
            for key in scores.keys()
            if key.replace('_score', '') in self.scoring_weights
        )
        
        scores['overall_score'] = min(overall_score, 100)  # Cap at 100
        
        # Add detailed breakdown
        scores['breakdown'] = self._generate_score_breakdown(scores, nlp_analysis)
        
        return scores
    
    def _calculate_skills_score(self, extracted_skills, job_description, classification_result):
        """Calculate skills matching score"""
        if not extracted_skills:
            return 0
        
        base_score = len(extracted_skills) * 2  # 2 points per skill
        
        # Bonus for relevant skills based on job description
        if job_description:
            job_desc_lower = job_description.lower()
            relevant_skills = 0
            
            for skill in extracted_skills:
                if skill.lower() in job_desc_lower:
                    relevant_skills += 1
            
            relevance_bonus = (relevant_skills / len(extracted_skills)) * 30
            base_score += relevance_bonus
        
        # Bonus for high-confidence classification
        if classification_result and classification_result.get('top_prediction'):
            confidence = classification_result['top_prediction'].get('confidence', 0)
            confidence_bonus = confidence * 20
            base_score += confidence_bonus
        
        return min(base_score, 100)
    
    def _calculate_experience_score(self, experience_info, resume_text):
        """Calculate experience-related score"""
        base_score = 0
        
        # Years of experience
        total_years = experience_info.get('total_years')
        if total_years:
            # Score based on years of experience (diminishing returns after 10 years)
            year_score = min(total_years * 8, 60)
            base_score += year_score
        
        # Experience mentions and descriptions
        experience_mentions = experience_info.get('experience_mentions', [])
        mention_score = len(experience_mentions) * 5
        base_score += min(mention_score, 20)
        
        # Look for action words that indicate strong experience
        action_words = [
            'led', 'managed', 'developed', 'implemented', 'created', 'designed',
            'optimized', 'improved', 'achieved', 'delivered', 'built', 'launched'
        ]
        
        text_lower = resume_text.lower()
        action_count = sum(1 for word in action_words if word in text_lower)
        action_score = min(action_count * 3, 20)
        base_score += action_score
        
        return min(base_score, 100)
    
    def _calculate_education_score(self, education_info, resume_text):
        """Calculate education-related score"""
        if not education_info:
            return 30  # Base score for resumes without clear education section
        
        base_score = 40  # Base score for having education information
        
        # Education level scoring
        education_text = ' '.join(education_info).lower()
        
        education_levels = {
            'phd': 25, 'doctorate': 25, 'doctoral': 25,
            'master': 20, 'mba': 20, 'ms': 20, 'ma': 20,
            'bachelor': 15, 'bs': 15, 'ba': 15,
            'associate': 10, 'diploma': 10, 'certificate': 8
        }
        
        highest_education_score = 0
        for level, score in education_levels.items():
            if level in education_text:
                highest_education_score = max(highest_education_score, score)
        
        base_score += highest_education_score
        
        # Bonus for prestigious institutions or relevant degrees
        prestige_keywords = [
            'university', 'institute', 'college', 'technology',
            'engineering', 'computer science', 'business', 'management'
        ]
        
        prestige_bonus = sum(2 for keyword in prestige_keywords if keyword in education_text)
        base_score += min(prestige_bonus, 10)
        
        return min(base_score, 100)
    
    def _calculate_keyword_score(self, keywords, job_description, resume_text):
        """Calculate keyword relevance score"""
        if not keywords:
            return 30
        
        base_score = len(keywords) * 1.5  # Base points for having keywords
        
        if job_description:
            job_words = set(job_description.lower().split())
            resume_words = set(resume_text.lower().split())
            
            # Calculate keyword overlap
            overlap = len(job_words.intersection(resume_words))
            total_job_words = len(job_words)
            
            if total_job_words > 0:
                overlap_ratio = overlap / total_job_words
                overlap_score = overlap_ratio * 40
                base_score += overlap_score
        
        # Bonus for technical keywords
        technical_keywords = [
            'api', 'database', 'cloud', 'agile', 'scrum', 'git',
            'testing', 'debugging', 'optimization', 'architecture'
        ]
        
        tech_bonus = sum(2 for keyword in keywords if keyword.lower() in technical_keywords)
        base_score += min(tech_bonus, 20)
        
        return min(base_score, 100)
    
    def _calculate_format_score(self, resume_text, nlp_analysis):
        """Calculate format and presentation quality score"""
        base_score = 50  # Start with average score
        
        # Text statistics
        text_stats = nlp_analysis.get('text_stats', {})
        word_count = text_stats.get('word_count', 0)
        
        # Optimal word count bonus/penalty
        if 300 <= word_count <= 800:
            base_score += 15
        elif word_count < 200:
            base_score -= 10
        elif word_count > 1200:
            base_score -= 5
        
        # Contact information bonus
        contact_info = nlp_analysis.get('contact_info', {})
        if contact_info.get('email'):
            base_score += 10
        if contact_info.get('phone'):
            base_score += 5
        if contact_info.get('linkedin'):
            base_score += 5
        
        # Structure indicators
        structure_keywords = ['summary', 'objective', 'experience', 'education', 'skills', 'projects']
        structure_score = sum(3 for keyword in structure_keywords if keyword in resume_text.lower())
        base_score += min(structure_score, 15)
        
        # Penalty for excessive repetition
        words = resume_text.lower().split()
        unique_words = set(words)
        if len(words) > 0:
            repetition_ratio = len(unique_words) / len(words)
            if repetition_ratio < 0.3:  # Too much repetition
                base_score -= 10
        
        return min(max(base_score, 0), 100)
    
    def _generate_score_breakdown(self, scores, nlp_analysis):
        """Generate detailed score breakdown with recommendations"""
        breakdown = {
            'strengths': [],
            'areas_for_improvement': [],
            'recommendations': []
        }
        
        # Analyze strengths
        if scores['skills_score'] >= 70:
            breakdown['strengths'].append("Strong technical skills portfolio")
        if scores['experience_score'] >= 70:
            breakdown['strengths'].append("Solid professional experience")
        if scores['education_score'] >= 70:
            breakdown['strengths'].append("Good educational background")
        if scores['format_score'] >= 70:
            breakdown['strengths'].append("Well-formatted resume")
        
        # Identify areas for improvement
        if scores['skills_score'] < 50:
            breakdown['areas_for_improvement'].append("Limited technical skills mentioned")
            breakdown['recommendations'].append("Add more relevant technical skills and certifications")
        
        if scores['experience_score'] < 50:
            breakdown['areas_for_improvement'].append("Insufficient experience details")
            breakdown['recommendations'].append("Include more specific achievements and quantifiable results")
        
        if scores['education_score'] < 50:
            breakdown['areas_for_improvement'].append("Education section needs enhancement")
            breakdown['recommendations'].append("Provide more details about educational background and relevant coursework")
        
        if scores['keyword_score'] < 50:
            breakdown['areas_for_improvement'].append("Low keyword relevance")
            breakdown['recommendations'].append("Include more industry-specific keywords and terms")
        
        if scores['format_score'] < 50:
            breakdown['areas_for_improvement'].append("Resume format needs improvement")
            breakdown['recommendations'].append("Improve structure, add contact information, and ensure proper formatting")
        
        # Overall recommendations
        overall_score = scores['overall_score']
        if overall_score < 40:
            breakdown['recommendations'].append("Consider a major revision of your resume structure and content")
        elif overall_score < 60:
            breakdown['recommendations'].append("Focus on highlighting your key achievements and skills more effectively")
        elif overall_score < 80:
            breakdown['recommendations'].append("Minor improvements in specific areas could significantly enhance your resume")
        else:
            breakdown['recommendations'].append("Excellent resume! Consider tailoring it for specific job applications")
        
        return breakdown
    
    def compare_resumes(self, resume_scores):
        """Compare multiple resumes and provide ranking"""
        if not resume_scores:
            return []
        
        # Sort by overall score
        sorted_resumes = sorted(
            resume_scores,
            key=lambda x: x['score']['overall_score'],
            reverse=True
        )
        
        # Add ranking information
        for i, resume in enumerate(sorted_resumes):
            resume['rank'] = i + 1
            resume['percentile'] = ((len(sorted_resumes) - i) / len(sorted_resumes)) * 100
        
        return sorted_resumes
