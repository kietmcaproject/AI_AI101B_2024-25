import streamlit as st
import re
from collections import Counter

class BERTClassifier:
    """BERT-based resume classification for job role matching"""
    
    def __init__(self):
        self.model_name = "microsoft/DialoGPT-medium"  # Using a more accessible model
        self.job_roles = [
            "Software Engineer",
            "Data Scientist",
            "Product Manager",
            "UX/UI Designer",
            "DevOps Engineer",
            "Marketing Specialist",
            "Sales Representative",
            "Business Analyst",
            "Project Manager",
            "Quality Assurance",
            "Frontend Developer",
            "Backend Developer",
            "Full Stack Developer",
            "Machine Learning Engineer",
            "Data Analyst",
            "Cybersecurity Specialist",
            "System Administrator",
            "Technical Writer",
            "HR Specialist",
            "Finance Analyst"
        ]
        self._initialize_classifier()
    
    def _initialize_classifier(self):
        """Initialize the BERT classifier"""
        # Using rule-based classification for better compatibility
        self.classifier = None
    
    def classify_resume(self, resume_text):
        """Classify resume into job roles with confidence scores"""
        return self._rule_based_classify(resume_text)
    
    def _bert_classify(self, resume_text):
        """Use BERT model for classification - Currently using rule-based approach"""
        return self._rule_based_classify(resume_text)
    
    def _rule_based_classify(self, resume_text):
        """Fallback rule-based classification using keyword matching"""
        text_lower = resume_text.lower()
        
        # Define keywords for each job role
        role_keywords = {
            "Software Engineer": ["python", "java", "programming", "software", "development", "coding", "algorithm"],
            "Data Scientist": ["machine learning", "python", "statistics", "data analysis", "pandas", "numpy", "ml"],
            "Frontend Developer": ["javascript", "html", "css", "react", "vue", "angular", "frontend", "ui"],
            "Backend Developer": ["api", "database", "server", "backend", "sql", "microservices", "django", "flask"],
            "Full Stack Developer": ["full stack", "frontend", "backend", "web development", "react", "node.js"],
            "Data Analyst": ["excel", "sql", "data analysis", "reporting", "tableau", "power bi", "analytics"],
            "DevOps Engineer": ["docker", "kubernetes", "aws", "azure", "jenkins", "ci/cd", "devops", "cloud"],
            "Product Manager": ["product management", "roadmap", "stakeholder", "requirements", "agile", "scrum"],
            "UX/UI Designer": ["ux", "ui", "design", "figma", "sketch", "user experience", "wireframe", "prototype"],
            "Quality Assurance": ["testing", "qa", "quality assurance", "automation", "selenium", "test cases"],
            "Machine Learning Engineer": ["machine learning", "deep learning", "tensorflow", "pytorch", "ml", "ai"],
            "Cybersecurity Specialist": ["security", "cybersecurity", "penetration testing", "vulnerability", "firewall"],
            "System Administrator": ["system admin", "linux", "windows server", "network", "infrastructure"],
            "Business Analyst": ["business analysis", "requirements", "stakeholder", "process improvement"],
            "Project Manager": ["project management", "pmp", "agile", "scrum", "waterfall", "timeline"],
            "Technical Writer": ["technical writing", "documentation", "content", "writing", "technical communication"],
            "Marketing Specialist": ["marketing", "digital marketing", "seo", "social media", "campaign"],
            "Sales Representative": ["sales", "crm", "lead generation", "customer relationship", "revenue"],
            "HR Specialist": ["human resources", "hr", "recruitment", "hiring", "employee relations"],
            "Finance Analyst": ["finance", "financial analysis", "accounting", "budgeting", "financial modeling"]
        }
        
        role_scores = {}
        
        for role, keywords in role_keywords.items():
            score = 0
            for keyword in keywords:
                # Count keyword occurrences (case insensitive)
                occurrences = len(re.findall(r'\b' + re.escape(keyword) + r'\b', text_lower))
                score += occurrences
            
            # Normalize score by number of keywords
            role_scores[role] = score / len(keywords)
        
        # Sort by score
        sorted_roles = sorted(role_scores.items(), key=lambda x: x[1], reverse=True)
        
        # Convert to predictions format
        predictions = []
        max_score = max(role_scores.values()) if role_scores.values() else 1
        
        for role, score in sorted_roles:
            if score > 0:  # Only include roles with some matches
                confidence = min(score / max_score, 1.0) if max_score > 0 else 0
                predictions.append({
                    'role': role,
                    'confidence': confidence
                })
        
        # If no matches found, assign default low confidence
        if not predictions:
            predictions = [{'role': 'General', 'confidence': 0.1}]
        
        return {
            'method': 'Rule-based',
            'predictions': predictions[:10],  # Top 10 predictions
            'top_prediction': predictions[0] if predictions else None
        }
    
    def get_role_requirements(self, role):
        """Get typical requirements for a job role"""
        requirements = {
            "Software Engineer": ["Programming languages", "Data structures", "Algorithms", "Software design"],
            "Data Scientist": ["Statistics", "Machine learning", "Python/R", "Data visualization"],
            "Frontend Developer": ["HTML/CSS", "JavaScript", "React/Vue/Angular", "UI/UX principles"],
            "Backend Developer": ["Server-side languages", "Databases", "APIs", "System design"],
            "DevOps Engineer": ["Cloud platforms", "Containerization", "CI/CD", "Infrastructure as code"],
            "Product Manager": ["Product strategy", "Market research", "Stakeholder management", "Agile methodology"]
        }
        
        return requirements.get(role, ["Domain expertise", "Problem solving", "Communication", "Teamwork"])
