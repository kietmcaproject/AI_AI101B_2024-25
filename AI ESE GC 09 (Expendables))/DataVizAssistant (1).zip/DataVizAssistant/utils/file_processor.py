import streamlit as st
import PyPDF2
from docx import Document
import io
import re

class FileProcessor:
    """Handles text extraction from various file formats"""
    
    def __init__(self):
        self.supported_formats = ['pdf', 'docx', 'txt']
    
    def extract_text(self, uploaded_file):
        """Extract text from uploaded file based on file type"""
        file_extension = uploaded_file.name.split('.')[-1].lower()
        
        try:
            if file_extension == 'pdf':
                return self._extract_from_pdf(uploaded_file)
            elif file_extension == 'docx':
                return self._extract_from_docx(uploaded_file)
            elif file_extension == 'txt':
                return self._extract_from_txt(uploaded_file)
            else:
                st.error(f"Unsupported file format: {file_extension}")
                return None
        except Exception as e:
            st.error(f"Error processing file: {str(e)}")
            return None
    
    def _extract_from_pdf(self, uploaded_file):
        """Extract text from PDF file"""
        text_content = ""
        
        try:
            pdf_reader = PyPDF2.PdfReader(io.BytesIO(uploaded_file.read()))
            
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                text_content += page.extract_text() + "\n"
            
            return self._clean_text(text_content)
        except Exception as e:
            st.error(f"Error reading PDF: {str(e)}")
            return None
    
    def _extract_from_docx(self, uploaded_file):
        """Extract text from DOCX file"""
        try:
            doc = Document(io.BytesIO(uploaded_file.read()))
            text_content = ""
            
            for paragraph in doc.paragraphs:
                text_content += paragraph.text + "\n"
            
            # Also extract text from tables
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        text_content += cell.text + " "
                    text_content += "\n"
            
            return self._clean_text(text_content)
        except Exception as e:
            st.error(f"Error reading DOCX: {str(e)}")
            return None
    
    def _extract_from_txt(self, uploaded_file):
        """Extract text from TXT file"""
        try:
            # Try different encodings
            encodings = ['utf-8', 'latin-1', 'cp1252']
            
            for encoding in encodings:
                try:
                    text_content = uploaded_file.read().decode(encoding)
                    return self._clean_text(text_content)
                except UnicodeDecodeError:
                    continue
            
            st.error("Could not decode text file with supported encodings")
            return None
        except Exception as e:
            st.error(f"Error reading TXT: {str(e)}")
            return None
    
    def _clean_text(self, text):
        """Clean and normalize extracted text"""
        if not text:
            return ""
        
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove special characters but keep basic punctuation
        text = re.sub(r'[^\w\s.,;:!?()-]', ' ', text)
        
        # Remove multiple consecutive spaces
        text = re.sub(r' +', ' ', text)
        
        # Strip leading/trailing whitespace
        text = text.strip()
        
        return text
    
    def get_file_info(self, uploaded_file):
        """Get basic information about the uploaded file"""
        return {
            'name': uploaded_file.name,
            'size': uploaded_file.size,
            'type': uploaded_file.type,
            'extension': uploaded_file.name.split('.')[-1].lower()
        }
