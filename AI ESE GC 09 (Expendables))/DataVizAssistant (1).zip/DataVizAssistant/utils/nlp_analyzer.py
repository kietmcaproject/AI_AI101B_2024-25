import streamlit as st
import spacy
import re
from collections import Counter
import string

class NLPAnalyzer:
    """NLP-based resume analysis for skill extraction and entity recognition"""
    
    def __init__(self):
        self.nlp = self._load_spacy_model()
        self.skill_patterns = self._define_skill_patterns()
        self.experience_patterns = self._define_experience_patterns()
    
    def _load_spacy_model(self):
        """Load spaCy model with fallback options"""
        try:
            # Try to load the full English model
            nlp = spacy.load("en_core_web_sm")
            return nlp
        except OSError:
            try:
                # Fallback to basic English model
                nlp = spacy.load("en")
                return nlp
            except OSError:
                st.warning("spaCy model not found. Using basic text processing.")
                return None
    
    def _define_skill_patterns(self):
        """Define patterns for skill extraction"""
        technical_skills = [
            # Programming Languages
            "python", "java", "javascript", "typescript", "c++", "c#", "ruby", "php", "go", "rust",
            "swift", "kotlin", "scala", "perl", "r", "matlab", "sql", "html", "css", "xml", "json",
            
            # Frameworks and Libraries
            "react", "angular", "vue", "django", "flask", "spring", "node.js", "express", "fastapi",
            "tensorflow", "pytorch", "scikit-learn", "pandas", "numpy", "matplotlib", "seaborn",
            "jquery", "bootstrap", "tailwind", "sass", "less",
            
            # Databases
            "mysql", "postgresql", "mongodb", "redis", "cassandra", "elasticsearch", "sqlite", "oracle",
            
            # Cloud and DevOps
            "aws", "azure", "gcp", "docker", "kubernetes", "jenkins", "git", "github", "gitlab",
            "terraform", "ansible", "puppet", "chef", "vagrant", "ci/cd", "devops",
            
            # Data Science and ML
            "machine learning", "deep learning", "neural networks", "nlp", "computer vision",
            "data analysis", "data science", "statistics", "tableau", "power bi", "spark", "hadoop",
            
            # Other Technologies
            "microservices", "api", "rest", "graphql", "websocket", "oauth", "jwt", "ssl", "tls",
            "agile", "scrum", "kanban", "jira", "confluence", "slack", "teams"
        ]
        
        return technical_skills
    
    def _define_experience_patterns(self):
        """Define patterns for experience extraction"""
        return [
            r'(\d+)\s*(?:years?|yrs?)\s*(?:of\s*)?(?:experience|exp)',
            r'(\d+)\+\s*(?:years?|yrs?)',
            r'(\d+)\s*to\s*(\d+)\s*(?:years?|yrs?)',
            r'(\d+)-(\d+)\s*(?:years?|yrs?)'
        ]
    
    def analyze_resume(self, resume_text):
        """Perform comprehensive NLP analysis on resume text"""
        analysis_result = {
            'skills': self._extract_skills(resume_text),
            'entities': self._extract_entities(resume_text),
            'experience': self._extract_experience(resume_text),
            'education': self._extract_education(resume_text),
            'contact_info': self._extract_contact_info(resume_text),
            'keywords': self._extract_keywords(resume_text),
            'sentiment': self._analyze_sentiment(resume_text),
            'text_stats': self._get_text_statistics(resume_text)
        }
        
        return analysis_result
    
    def _extract_skills(self, text):
        """Extract technical skills from resume text"""
        text_lower = text.lower()
        found_skills = []
        
        # Remove punctuation for better matching
        text_clean = text_lower.translate(str.maketrans('', '', string.punctuation))
        
        for skill in self.skill_patterns:
            # Use word boundaries to avoid partial matches
            pattern = r'\b' + re.escape(skill.lower()) + r'\b'
            if re.search(pattern, text_clean):
                found_skills.append(skill.title())
        
        # Remove duplicates and sort
        unique_skills = list(set(found_skills))
        unique_skills.sort()
        
        return unique_skills
    
    def _extract_entities(self, text):
        """Extract named entities using spaCy"""
        if not self.nlp:
            return self._extract_entities_basic(text)
        
        doc = self.nlp(text)
        entities = []
        
        for ent in doc.ents:
            if ent.label_ in ['PERSON', 'ORG', 'GPE', 'DATE', 'MONEY', 'PERCENT']:
                entities.append({
                    'text': ent.text,
                    'label': ent.label_,
                    'description': spacy.explain(ent.label_)
                })
        
        return entities[:20]  # Return top 20 entities
    
    def _extract_entities_basic(self, text):
        """Basic entity extraction without spaCy"""
        entities = []
        
        # Extract email addresses
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, text)
        for email in emails:
            entities.append({'text': email, 'label': 'EMAIL', 'description': 'Email address'})
        
        # Extract phone numbers
        phone_pattern = r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'
        phones = re.findall(phone_pattern, text)
        for phone in phones:
            entities.append({'text': phone, 'label': 'PHONE', 'description': 'Phone number'})
        
        # Extract years (likely dates)
        year_pattern = r'\b(19|20)\d{2}\b'
        years = re.findall(year_pattern, text)
        for year in set(years):
            entities.append({'text': year, 'label': 'DATE', 'description': 'Year'})
        
        return entities
    
    def _extract_experience(self, text):
        """Extract years of experience from resume text"""
        experience_info = {
            'total_years': None,
            'experience_mentions': []
        }
        
        for pattern in self.experience_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                experience_info['experience_mentions'].append(match.group())
                
                # Try to extract numeric value
                numbers = re.findall(r'\d+', match.group())
                if numbers:
                    years = max([int(num) for num in numbers])
                    if experience_info['total_years'] is None or years > experience_info['total_years']:
                        experience_info['total_years'] = years
        
        return experience_info
    
    def _extract_education(self, text):
        """Extract education information"""
        education_keywords = [
            'bachelor', 'master', 'phd', 'doctorate', 'diploma', 'certificate',
            'degree', 'university', 'college', 'school', 'institute',
            'bs', 'ba', 'ms', 'ma', 'mba', 'phd'
        ]
        
        education_info = []
        text_lower = text.lower()
        
        for keyword in education_keywords:
            if keyword in text_lower:
                # Find context around the keyword
                pattern = r'.{0,50}\b' + re.escape(keyword) + r'\b.{0,50}'
                matches = re.findall(pattern, text_lower, re.IGNORECASE)
                education_info.extend(matches)
        
        return list(set(education_info))[:10]  # Return unique education mentions
    
    def _extract_contact_info(self, text):
        """Extract contact information"""
        contact_info = {}
        
        # Email
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, text)
        if emails:
            contact_info['email'] = emails[0]
        
        # Phone
        phone_patterns = [
            r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            r'\(\d{3}\)\s*\d{3}[-.]?\d{4}',
            r'\+\d{1,3}\s*\d{3,4}[-.]?\d{3,4}[-.]?\d{4}'
        ]
        
        for pattern in phone_patterns:
            phones = re.findall(pattern, text)
            if phones:
                contact_info['phone'] = phones[0]
                break
        
        # LinkedIn
        linkedin_pattern = r'linkedin\.com/in/[\w-]+'
        linkedin = re.findall(linkedin_pattern, text, re.IGNORECASE)
        if linkedin:
            contact_info['linkedin'] = linkedin[0]
        
        return contact_info
    
    def _extract_keywords(self, text):
        """Extract important keywords from resume"""
        if not self.nlp:
            return self._extract_keywords_basic(text)
        
        doc = self.nlp(text)
        
        # Extract important words (nouns, proper nouns, adjectives)
        keywords = []
        for token in doc:
            if (token.pos_ in ['NOUN', 'PROPN', 'ADJ'] and 
                not token.is_stop and 
                not token.is_punct and 
                len(token.text) > 2):
                keywords.append(token.lemma_.lower())
        
        # Count frequency and return top keywords
        keyword_freq = Counter(keywords)
        return [word for word, count in keyword_freq.most_common(20)]
    
    def _extract_keywords_basic(self, text):
        """Basic keyword extraction without spaCy"""
        # Simple approach: extract common resume keywords
        resume_keywords = [
            'experience', 'skills', 'education', 'projects', 'achievements',
            'responsible', 'managed', 'developed', 'implemented', 'created',
            'led', 'collaborated', 'analyzed', 'designed', 'optimized'
        ]
        
        found_keywords = []
        text_lower = text.lower()
        
        for keyword in resume_keywords:
            if keyword in text_lower:
                found_keywords.append(keyword)
        
        return found_keywords
    
    def _analyze_sentiment(self, text):
        """Basic sentiment analysis"""
        positive_words = ['achieve', 'success', 'excellent', 'outstanding', 'improve', 'optimize', 'lead', 'manage']
        negative_words = ['problem', 'issue', 'difficult', 'challenge', 'failed', 'error']
        
        text_lower = text.lower()
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        total_words = len(text.split())
        positive_ratio = positive_count / total_words if total_words > 0 else 0
        negative_ratio = negative_count / total_words if total_words > 0 else 0
        
        if positive_ratio > negative_ratio:
            sentiment = 'positive'
        elif negative_ratio > positive_ratio:
            sentiment = 'negative'
        else:
            sentiment = 'neutral'
        
        return {
            'sentiment': sentiment,
            'positive_ratio': positive_ratio,
            'negative_ratio': negative_ratio,
            'confidence': abs(positive_ratio - negative_ratio)
        }
    
    def _get_text_statistics(self, text):
        """Get basic text statistics"""
        words = text.split()
        sentences = text.split('.')
        
        return {
            'word_count': len(words),
            'sentence_count': len(sentences),
            'character_count': len(text),
            'average_word_length': sum(len(word) for word in words) / len(words) if words else 0,
            'average_sentence_length': len(words) / len(sentences) if sentences else 0
        }
