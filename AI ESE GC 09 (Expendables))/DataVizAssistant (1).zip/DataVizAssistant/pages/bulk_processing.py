import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from utils.file_processor import FileProcessor
from utils.bert_classifier import BERTClassifier
from utils.nlp_analyzer import NLPAnalyzer
from utils.resume_scorer import ResumeScorer
import json
from datetime import datetime
import zipfile
import io

def bulk_processing_page():
    st.header("📁 Bulk Resume Processing")
    st.write("Upload multiple resumes for batch processing and comparison.")
    
    # Job description for bulk processing
    st.subheader("Job Requirements")
    job_description = st.text_area(
        "Enter job description for better matching:",
        height=120,
        placeholder="Enter the job requirements, skills, and qualifications you're looking for..."
    )
    
    # Bulk file upload
    st.subheader("Upload Resumes")
    uploaded_files = st.file_uploader(
        "Choose multiple resume files",
        type=['pdf', 'docx', 'txt'],
        accept_multiple_files=True,
        help="You can upload multiple files at once"
    )
    
    if uploaded_files:
        st.info(f"📊 {len(uploaded_files)} files uploaded")
        
        # Processing options
        col1, col2 = st.columns(2)
        with col1:
            process_button = st.button("🚀 Process All Resumes", type="primary")
        with col2:
            clear_button = st.button("🗑️ Clear Results")
        
        if clear_button:
            if 'bulk_results' in st.session_state:
                del st.session_state.bulk_results
            st.rerun()
        
        if process_button:
            process_bulk_resumes(uploaded_files, job_description)
        
        # Display results if available
        if 'bulk_results' in st.session_state and st.session_state.bulk_results:
            display_bulk_results()

def process_bulk_resumes(uploaded_files, job_description):
    """Process multiple resumes in bulk"""
    file_processor = FileProcessor()
    
    # Initialize models
    if 'bert_classifier' not in st.session_state or st.session_state.bert_classifier is None:
        st.session_state.bert_classifier = BERTClassifier()
    if 'nlp_analyzer' not in st.session_state or st.session_state.nlp_analyzer is None:
        st.session_state.nlp_analyzer = NLPAnalyzer()
    if 'resume_scorer' not in st.session_state or st.session_state.resume_scorer is None:
        st.session_state.resume_scorer = ResumeScorer()
    
    results = []
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    for i, uploaded_file in enumerate(uploaded_files):
        status_text.text(f"Processing {uploaded_file.name}...")
        progress_bar.progress((i + 1) / len(uploaded_files))
        
        try:
            # Extract text
            text_content = file_processor.extract_text(uploaded_file)
            
            if text_content:
                # Classify resume
                classification_result = st.session_state.bert_classifier.classify_resume(text_content)
                
                # Analyze with NLP
                nlp_result = st.session_state.nlp_analyzer.analyze_resume(text_content)
                
                # Score resume
                score_result = st.session_state.resume_scorer.score_resume(
                    text_content, 
                    job_description,
                    classification_result,
                    nlp_result
                )
                
                result = {
                    'filename': uploaded_file.name,
                    'text_content': text_content,
                    'classification': classification_result,
                    'nlp_analysis': nlp_result,
                    'score': score_result,
                    'processed_at': datetime.now().isoformat(),
                    'file_size': uploaded_file.size
                }
                
                results.append(result)
            else:
                st.warning(f"Could not extract text from {uploaded_file.name}")
                
        except Exception as e:
            st.error(f"Error processing {uploaded_file.name}: {str(e)}")
    
    progress_bar.progress(1.0)
    status_text.text("Processing complete!")
    
    # Store results in session state
    st.session_state.bulk_results = results
    
    # Rank resumes
    ranked_results = st.session_state.resume_scorer.compare_resumes(results)
    st.session_state.bulk_results = ranked_results
    
    st.success(f"✅ Successfully processed {len(results)} out of {len(uploaded_files)} resumes")

def display_bulk_results():
    """Display bulk processing results"""
    results = st.session_state.bulk_results
    
    if not results:
        st.warning("No results to display")
        return
    
    # Summary statistics
    st.subheader("📊 Processing Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Resumes", len(results))
    
    with col2:
        avg_score = sum(r['score']['overall_score'] for r in results) / len(results)
        st.metric("Average Score", f"{avg_score:.1f}")
    
    with col3:
        top_score = max(r['score']['overall_score'] for r in results)
        st.metric("Highest Score", f"{top_score:.1f}")
    
    with col4:
        qualified_count = sum(1 for r in results if r['score']['overall_score'] >= 70)
        st.metric("Qualified Candidates", qualified_count)
    
    # Score distribution chart
    st.subheader("📈 Score Distribution")
    
    scores = [r['score']['overall_score'] for r in results]
    fig = px.histogram(
        x=scores,
        nbins=10,
        title="Resume Score Distribution",
        labels={'x': 'Score', 'y': 'Number of Resumes'}
    )
    fig.update_layout(showlegend=False)
    st.plotly_chart(fig, use_container_width=True)
    
    # Top candidates table
    st.subheader("🏆 Top Candidates")
    
    # Create DataFrame for display
    display_data = []
    for result in results[:10]:  # Top 10
        top_role = result['classification']['predictions'][0] if result['classification']['predictions'] else {'role': 'Unknown', 'confidence': 0}
        
        display_data.append({
            'Rank': result.get('rank', 0),
            'Resume': result['filename'],
            'Overall Score': f"{result['score']['overall_score']:.1f}",
            'Predicted Role': top_role['role'],
            'Confidence': f"{top_role['confidence']:.1%}",
            'Skills Count': len(result['nlp_analysis'].get('skills', [])),
            'Experience': result['nlp_analysis']['experience'].get('total_years', 'N/A')
        })
    
    df = pd.DataFrame(display_data)
    st.dataframe(df, use_container_width=True)
    
    # Skills analysis
    st.subheader("🔧 Skills Analysis")
    
    # Aggregate all skills
    all_skills = []
    for result in results:
        all_skills.extend(result['nlp_analysis'].get('skills', []))
    
    if all_skills:
        # Count skill frequency
        from collections import Counter
        skill_counts = Counter(all_skills)
        top_skills = skill_counts.most_common(15)
        
        # Create skills chart
        skills_df = pd.DataFrame(top_skills, columns=['Skill', 'Count'])
        fig = px.bar(
            skills_df,
            x='Count',
            y='Skill',
            orientation='h',
            title="Most Common Skills Across All Resumes"
        )
        fig.update_layout(yaxis={'categoryorder': 'total ascending'})
        st.plotly_chart(fig, use_container_width=True)
    
    # Role distribution
    st.subheader("👔 Role Distribution")
    
    roles = []
    for result in results:
        if result['classification']['predictions']:
            roles.append(result['classification']['predictions'][0]['role'])
    
    if roles:
        from collections import Counter
        role_counts = Counter(roles)
        roles_df = pd.DataFrame(role_counts.most_common(), columns=['Role', 'Count'])
        
        fig = px.pie(
            roles_df,
            values='Count',
            names='Role',
            title="Predicted Role Distribution"
        )
        st.plotly_chart(fig, use_container_width=True)
    
    # Detailed results with filtering
    st.subheader("📋 Detailed Results")
    
    # Filters
    col1, col2, col3 = st.columns(3)
    
    with col1:
        min_score = st.slider("Minimum Score", 0, 100, 0)
    
    with col2:
        selected_roles = st.multiselect(
            "Filter by Role",
            options=list(set(roles)) if roles else [],
            default=[]
        )
    
    with col3:
        sort_by = st.selectbox(
            "Sort by",
            ["Score (High to Low)", "Score (Low to High)", "Filename", "Processing Time"]
        )
    
    # Filter and sort results
    filtered_results = []
    for result in results:
        score = result['score']['overall_score']
        role = result['classification']['predictions'][0]['role'] if result['classification']['predictions'] else 'Unknown'
        
        # Apply filters
        if score >= min_score:
            if not selected_roles or role in selected_roles:
                filtered_results.append(result)
    
    # Sort results
    if sort_by == "Score (High to Low)":
        filtered_results.sort(key=lambda x: x['score']['overall_score'], reverse=True)
    elif sort_by == "Score (Low to High)":
        filtered_results.sort(key=lambda x: x['score']['overall_score'])
    elif sort_by == "Filename":
        filtered_results.sort(key=lambda x: x['filename'])
    elif sort_by == "Processing Time":
        filtered_results.sort(key=lambda x: x['processed_at'], reverse=True)
    
    # Display filtered results
    for result in filtered_results:
        with st.expander(f"📄 {result['filename']} - Score: {result['score']['overall_score']:.1f}"):
            display_individual_result(result)
    
    # Export options
    st.subheader("📥 Export Results")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📊 Export to CSV"):
            csv_data = create_csv_export(results)
            st.download_button(
                label="Download CSV",
                data=csv_data,
                file_name=f"resume_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    
    with col2:
        if st.button("📋 Export to JSON"):
            json_data = create_json_export(results)
            st.download_button(
                label="Download JSON",
                data=json_data,
                file_name=f"resume_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )
    
    with col3:
        if st.button("📁 Export All Reports"):
            zip_data = create_zip_export(results)
            st.download_button(
                label="Download ZIP",
                data=zip_data,
                file_name=f"resume_reports_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip",
                mime="application/zip"
            )

def display_individual_result(result):
    """Display individual resume result in compact format"""
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Classification:**")
        top_pred = result['classification']['predictions'][0] if result['classification']['predictions'] else None
        if top_pred:
            st.write(f"• {top_pred['role']} ({top_pred['confidence']:.1%})")
        
        st.write("**Skills:**")
        skills = result['nlp_analysis'].get('skills', [])[:5]  # Show top 5
        for skill in skills:
            st.write(f"• {skill}")
    
    with col2:
        st.write("**Score Breakdown:**")
        score = result['score']
        st.write(f"• Overall: {score['overall_score']:.1f}")
        st.write(f"• Skills: {score.get('skills_score', 0):.1f}")
        st.write(f"• Experience: {score.get('experience_score', 0):.1f}")
        st.write(f"• Education: {score.get('education_score', 0):.1f}")

def create_csv_export(results):
    """Create CSV export of results"""
    data = []
    for result in results:
        top_role = result['classification']['predictions'][0] if result['classification']['predictions'] else {'role': 'Unknown', 'confidence': 0}
        
        row = {
            'Filename': result['filename'],
            'Overall_Score': result['score']['overall_score'],
            'Skills_Score': result['score'].get('skills_score', 0),
            'Experience_Score': result['score'].get('experience_score', 0),
            'Education_Score': result['score'].get('education_score', 0),
            'Format_Score': result['score'].get('format_score', 0),
            'Predicted_Role': top_role['role'],
            'Role_Confidence': top_role['confidence'],
            'Skills_Count': len(result['nlp_analysis'].get('skills', [])),
            'Experience_Years': result['nlp_analysis']['experience'].get('total_years', ''),
            'Contact_Email': result['nlp_analysis']['contact_info'].get('email', ''),
            'Contact_Phone': result['nlp_analysis']['contact_info'].get('phone', ''),
            'Processed_At': result['processed_at']
        }
        data.append(row)
    
    df = pd.DataFrame(data)
    return df.to_csv(index=False)

def create_json_export(results):
    """Create JSON export of results"""
    export_data = {
        'export_info': {
            'timestamp': datetime.now().isoformat(),
            'total_resumes': len(results),
            'version': '1.0'
        },
        'results': []
    }
    
    for result in results:
        export_result = {
            'filename': result['filename'],
            'score': result['score'],
            'classification': result['classification'],
            'skills': result['nlp_analysis'].get('skills', []),
            'experience': result['nlp_analysis'].get('experience', {}),
            'contact_info': result['nlp_analysis'].get('contact_info', {}),
            'processed_at': result['processed_at']
        }
        export_data['results'].append(export_result)
    
    return json.dumps(export_data, indent=2)

def create_zip_export(results):
    """Create ZIP file with individual reports"""
    zip_buffer = io.BytesIO()
    
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # Add summary CSV
        csv_data = create_csv_export(results)
        zip_file.writestr("summary.csv", csv_data)
        
        # Add individual JSON reports
        for result in results:
            filename_base = result['filename'].split('.')[0]
            report_data = {
                'filename': result['filename'],
                'analysis': {
                    'score': result['score'],
                    'classification': result['classification'],
                    'nlp_analysis': result['nlp_analysis']
                },
                'processed_at': result['processed_at']
            }
            
            json_content = json.dumps(report_data, indent=2)
            zip_file.writestr(f"reports/{filename_base}_report.json", json_content)
    
    zip_buffer.seek(0)
    return zip_buffer.getvalue()
