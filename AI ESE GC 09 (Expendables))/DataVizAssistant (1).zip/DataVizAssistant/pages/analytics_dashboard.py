import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from collections import Counter
from datetime import datetime, timedelta
import numpy as np

def analytics_dashboard_page():
    st.header("📊 Analytics Dashboard")
    st.write("Comprehensive analytics and insights from processed resumes.")
    
    # Check if we have data
    if 'bulk_results' not in st.session_state or not st.session_state.bulk_results:
        if 'processed_resumes' not in st.session_state or not st.session_state.processed_resumes:
            st.warning("⚠️ No resume data available. Please process some resumes first.")
            st.info("💡 Go to 'Single Resume Processing' or 'Bulk Processing' to analyze resumes.")
            return
        else:
            # Use single resume data if bulk data not available
            results = st.session_state.processed_resumes
    else:
        results = st.session_state.bulk_results
    
    # Dashboard controls
    st.subheader("🎛️ Dashboard Controls")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        date_range = st.selectbox(
            "Time Period",
            ["All Time", "Last 7 Days", "Last 30 Days", "Last 90 Days"]
        )
    
    with col2:
        min_score_filter = st.slider("Minimum Score Filter", 0, 100, 0)
    
    with col3:
        refresh_button = st.button("🔄 Refresh Dashboard")
    
    # Filter data based on controls
    filtered_results = filter_results(results, date_range, min_score_filter)
    
    if not filtered_results:
        st.warning("No data matches the current filters.")
        return
    
    # Main metrics
    display_key_metrics(filtered_results)
    
    # Charts and visualizations
    col1, col2 = st.columns(2)
    
    with col1:
        display_score_distribution(filtered_results)
        display_role_distribution(filtered_results)
    
    with col2:
        display_skills_analysis(filtered_results)
        display_experience_analysis(filtered_results)
    
    # Additional analytics
    display_correlation_analysis(filtered_results)
    display_competitive_analysis(filtered_results)
    display_trends_analysis(filtered_results)

def filter_results(results, date_range, min_score):
    """Filter results based on dashboard controls"""
    filtered = []
    
    # Date filtering
    if date_range != "All Time":
        days_map = {"Last 7 Days": 7, "Last 30 Days": 30, "Last 90 Days": 90}
        cutoff_date = datetime.now() - timedelta(days=days_map[date_range])
        
        for result in results:
            try:
                processed_date = datetime.fromisoformat(result['processed_at'])
                if processed_date >= cutoff_date and result['score']['overall_score'] >= min_score:
                    filtered.append(result)
            except:
                # If date parsing fails, include the result
                if result['score']['overall_score'] >= min_score:
                    filtered.append(result)
    else:
        filtered = [r for r in results if r['score']['overall_score'] >= min_score]
    
    return filtered

def display_key_metrics(results):
    """Display key performance metrics"""
    st.subheader("📈 Key Metrics")
    
    col1, col2, col3, col4, col5 = st.columns(5)
    
    # Calculate metrics
    total_resumes = len(results)
    avg_score = np.mean([r['score']['overall_score'] for r in results])
    high_performers = len([r for r in results if r['score']['overall_score'] >= 80])
    qualified_candidates = len([r for r in results if r['score']['overall_score'] >= 70])
    
    # Skills diversity
    all_skills = []
    for result in results:
        all_skills.extend(result['nlp_analysis'].get('skills', []))
    unique_skills = len(set(all_skills))
    
    with col1:
        st.metric("Total Resumes", total_resumes)
    
    with col2:
        st.metric("Average Score", f"{avg_score:.1f}")
    
    with col3:
        st.metric("High Performers", high_performers, f"{high_performers/total_resumes*100:.1f}%")
    
    with col4:
        st.metric("Qualified Candidates", qualified_candidates, f"{qualified_candidates/total_resumes*100:.1f}%")
    
    with col5:
        st.metric("Unique Skills", unique_skills)

def display_score_distribution(results):
    """Display score distribution chart"""
    st.subheader("📊 Score Distribution")
    
    scores = [r['score']['overall_score'] for r in results]
    
    # Create histogram
    fig = px.histogram(
        x=scores,
        nbins=20,
        title="Resume Score Distribution",
        labels={'x': 'Score', 'y': 'Count'},
        color_discrete_sequence=['#1f77b4']
    )
    
    # Add average line
    avg_score = np.mean(scores)
    fig.add_vline(x=avg_score, line_dash="dash", line_color="red", 
                  annotation_text=f"Avg: {avg_score:.1f}")
    
    # Add percentile lines
    p75 = np.percentile(scores, 75)
    p25 = np.percentile(scores, 25)
    
    fig.add_vline(x=p75, line_dash="dot", line_color="green", 
                  annotation_text=f"75th: {p75:.1f}")
    fig.add_vline(x=p25, line_dash="dot", line_color="orange", 
                  annotation_text=f"25th: {p25:.1f}")
    
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)

def display_role_distribution(results):
    """Display role distribution chart"""
    st.subheader("👔 Role Distribution")
    
    roles = []
    for result in results:
        if result['classification']['predictions']:
            roles.append(result['classification']['predictions'][0]['role'])
    
    if roles:
        role_counts = Counter(roles)
        
        # Create pie chart
        fig = px.pie(
            values=list(role_counts.values()),
            names=list(role_counts.keys()),
            title="Predicted Roles Distribution"
        )
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No role predictions available")

def display_skills_analysis(results):
    """Display skills analysis"""
    st.subheader("🔧 Skills Analysis")
    
    all_skills = []
    for result in results:
        all_skills.extend(result['nlp_analysis'].get('skills', []))
    
    if all_skills:
        skill_counts = Counter(all_skills)
        top_skills = skill_counts.most_common(15)
        
        skills_df = pd.DataFrame(top_skills, columns=['Skill', 'Count'])
        
        fig = px.bar(
            skills_df,
            x='Count',
            y='Skill',
            orientation='h',
            title="Most In-Demand Skills",
            color='Count',
            color_continuous_scale='Blues'
        )
        fig.update_layout(yaxis={'categoryorder': 'total ascending'}, height=400)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No skills data available")

def display_experience_analysis(results):
    """Display experience analysis"""
    st.subheader("💼 Experience Analysis")
    
    experience_data = []
    for result in results:
        exp_years = result['nlp_analysis']['experience'].get('total_years')
        if exp_years is not None:
            experience_data.append({
                'years': exp_years,
                'score': result['score']['overall_score']
            })
    
    if experience_data:
        exp_df = pd.DataFrame(experience_data)
        
        # Create scatter plot
        fig = px.scatter(
            exp_df,
            x='years',
            y='score',
            title="Experience vs Resume Score",
            labels={'years': 'Years of Experience', 'score': 'Resume Score'},
            trendline="ols"
        )
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
        
        # Experience distribution
        fig2 = px.histogram(
            exp_df,
            x='years',
            title="Experience Distribution",
            labels={'years': 'Years of Experience', 'count': 'Number of Candidates'},
            nbins=10
        )
        st.plotly_chart(fig2, use_container_width=True)
    else:
        st.info("No experience data available")

def display_correlation_analysis(results):
    """Display correlation analysis between different score components"""
    st.subheader("🔗 Score Component Correlation")
    
    # Prepare data for correlation analysis
    correlation_data = []
    for result in results:
        score = result['score']
        correlation_data.append({
            'Overall Score': score['overall_score'],
            'Skills Score': score.get('skills_score', 0),
            'Experience Score': score.get('experience_score', 0),
            'Education Score': score.get('education_score', 0),
            'Format Score': score.get('format_score', 0),
            'Keyword Score': score.get('keyword_score', 0)
        })
    
    if correlation_data:
        corr_df = pd.DataFrame(correlation_data)
        correlation_matrix = corr_df.corr()
        
        # Create heatmap
        fig = px.imshow(
            correlation_matrix,
            text_auto=True,
            title="Score Components Correlation Matrix",
            color_continuous_scale='RdBu',
            aspect="auto"
        )
        fig.update_layout(height=500)
        st.plotly_chart(fig, use_container_width=True)

def display_competitive_analysis(results):
    """Display competitive analysis and benchmarking"""
    st.subheader("🏆 Competitive Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Score percentiles
        scores = [r['score']['overall_score'] for r in results]
        percentiles = [10, 25, 50, 75, 90]
        percentile_values = [np.percentile(scores, p) for p in percentiles]
        
        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=[f"{p}th" for p in percentiles],
            y=percentile_values,
            name="Score Percentiles",
            marker_color='lightblue'
        ))
        
        fig.update_layout(
            title="Score Percentile Benchmarks",
            xaxis_title="Percentile",
            yaxis_title="Score",
            height=400
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Performance categories
        performance_categories = {
            'Excellent (80+)': len([r for r in results if r['score']['overall_score'] >= 80]),
            'Good (60-79)': len([r for r in results if 60 <= r['score']['overall_score'] < 80]),
            'Average (40-59)': len([r for r in results if 40 <= r['score']['overall_score'] < 60]),
            'Below Average (<40)': len([r for r in results if r['score']['overall_score'] < 40])
        }
        
        fig = px.bar(
            x=list(performance_categories.keys()),
            y=list(performance_categories.values()),
            title="Performance Category Distribution",
            color=list(performance_categories.values()),
            color_continuous_scale='Viridis'
        )
        fig.update_layout(height=400, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

def display_trends_analysis(results):
    """Display trends over time"""
    st.subheader("📈 Trends Analysis")
    
    # Process dates and create time series
    time_data = []
    for result in results:
        try:
            processed_date = datetime.fromisoformat(result['processed_at'])
            time_data.append({
                'date': processed_date.date(),
                'score': result['score']['overall_score']
            })
        except:
            continue
    
    if time_data:
        time_df = pd.DataFrame(time_data)
        
        # Group by date and calculate metrics
        daily_stats = time_df.groupby('date').agg({
            'score': ['mean', 'count', 'max', 'min']
        }).round(2)
        
        daily_stats.columns = ['Avg Score', 'Count', 'Max Score', 'Min Score']
        daily_stats = daily_stats.reset_index()
        
        # Create subplots
        fig = make_subplots(
            rows=2, cols=1,
            subplot_titles=['Average Daily Scores', 'Daily Resume Count'],
            vertical_spacing=0.1
        )
        
        # Average score trend
        fig.add_trace(
            go.Scatter(
                x=daily_stats['date'],
                y=daily_stats['Avg Score'],
                mode='lines+markers',
                name='Average Score',
                line=dict(color='blue')
            ),
            row=1, col=1
        )
        
        # Daily count
        fig.add_trace(
            go.Bar(
                x=daily_stats['date'],
                y=daily_stats['Count'],
                name='Resume Count',
                marker_color='lightgreen'
            ),
            row=2, col=1
        )
        
        fig.update_layout(height=600, title_text="Resume Processing Trends")
        fig.update_xaxes(title_text="Date", row=2, col=1)
        fig.update_yaxes(title_text="Score", row=1, col=1)
        fig.update_yaxes(title_text="Count", row=2, col=1)
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Summary insights
        st.subheader("💡 Key Insights")
        
        if len(daily_stats) > 1:
            latest_avg = daily_stats.iloc[-1]['Avg Score']
            previous_avg = daily_stats.iloc[-2]['Avg Score'] if len(daily_stats) > 1 else latest_avg
            trend = "improving" if latest_avg > previous_avg else "declining" if latest_avg < previous_avg else "stable"
            
            st.info(f"📊 The average resume quality is **{trend}** with the latest average score of **{latest_avg:.1f}**")
        
        total_processed = daily_stats['Count'].sum()
        avg_daily_volume = daily_stats['Count'].mean()
        
        st.info(f"📈 Total resumes processed: **{total_processed}** | Average daily volume: **{avg_daily_volume:.1f}**")
    else:
        st.info("No time series data available for trends analysis")
