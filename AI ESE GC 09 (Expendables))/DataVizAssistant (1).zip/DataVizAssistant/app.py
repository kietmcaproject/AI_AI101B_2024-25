import streamlit as st
import pandas as pd
import json
from datetime import datetime
import re
from collections import Counter
import io

# Page configuration
st.set_page_config(
    page_title="AI Resume Screening System",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for enhanced bright styling
st.markdown("""
<style>
    /* Main background - stunning gradient */
    .stApp {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 25%, #f093fb 50%, #f5576c 75%, #4facfe 100%);
        background-size: 400% 400%;
        animation: gradientShift 15s ease infinite;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        min-height: 100vh;
    }
    
    @keyframes gradientShift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    
    /* Header styling - vibrant and clear */
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 3rem 2rem;
        border-radius: 20px;
        margin-bottom: 2rem;
        box-shadow: 0 15px 40px rgba(102, 126, 234, 0.3);
        border: 2px solid rgba(255,255,255,0.3);
        position: relative;
        overflow: hidden;
    }
    
    .main-header::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        animation: rotate 20s linear infinite;
    }
    
    @keyframes rotate {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .main-header h1 {
        color: white;
        text-align: center;
        margin: 0;
        font-weight: 800;
        font-size: 2.5rem;
        text-shadow: 0 4px 8px rgba(0,0,0,0.3);
        position: relative;
        z-index: 1;
    }
    
    .main-header p {
        color: rgba(255,255,255,0.95);
        text-align: center;
        margin: 1rem 0 0 0;
        font-size: 1.2rem;
        font-weight: 500;
        position: relative;
        z-index: 1;
    }
    
    /* Sidebar styling */
    .css-1d391kg {
        background: linear-gradient(180deg, #667eea, #764ba2) !important;
    }
    
    /* Enhanced cards with bright backgrounds and compact design */
    .metric-card {
        background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 6px 20px rgba(0,0,0,0.1);
        margin: 1rem 0;
        border-left: 5px solid #4CAF50;
        border-top: 1px solid rgba(76, 175, 80, 0.2);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        backdrop-filter: blur(10px);
    }
    
    .metric-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    
    .metric-card h3, .metric-card h4 {
        color: #2c3e50 !important;
        margin: 0.3rem 0 !important;
        line-height: 1.3 !important;
    }
    
    .metric-card p {
        color: #4a5568 !important;
        margin: 0.3rem 0 !important;
        line-height: 1.4 !important;
    }
    
    .score-card {
        background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
        color: white;
        padding: 3rem 2rem;
        border-radius: 20px;
        text-align: center;
        box-shadow: 0 15px 40px rgba(76, 175, 80, 0.3);
        margin: 2rem 0;
        border: 2px solid rgba(255,255,255,0.2);
    }
    
    .skills-card {
        background: linear-gradient(145deg, #ffffff 0%, #f1f8ff 100%);
        padding: 2rem;
        border-radius: 15px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        margin: 1.5rem 0;
        border-top: 4px solid #2196F3;
        border-left: 1px solid rgba(33, 150, 243, 0.2);
    }
    
    .skills-card h3, .skills-card h4, .skills-card p, .skills-card li {
        color: #1565c0 !important;
    }
    
    .analysis-card {
        background: linear-gradient(145deg, #ffffff 0%, #fff8f0 100%);
        padding: 2rem;
        border-radius: 15px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        margin: 1.5rem 0;
        border-top: 4px solid #FF9800;
        border-left: 1px solid rgba(255, 152, 0, 0.2);
    }
    
    .analysis-card h3, .analysis-card h4, .analysis-card p, .analysis-card li {
        color: #e65100 !important;
    }
    
    /* Enhanced buttons with better visibility */
    .stButton > button {
        background: linear-gradient(45deg, #667eea, #764ba2) !important;
        color: white !important;
        border: none !important;
        border-radius: 25px !important;
        padding: 0.8rem 2.5rem !important;
        font-weight: 700 !important;
        font-size: 1rem !important;
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4) !important;
        transition: all 0.3s ease !important;
        text-transform: uppercase !important;
        letter-spacing: 1px !important;
    }
    
    .stButton > button:hover {
        transform: translateY(-3px) !important;
        box-shadow: 0 10px 30px rgba(102, 126, 234, 0.6) !important;
        background: linear-gradient(45deg, #5a67d8, #6b46c1) !important;
    }
    
    /* Enhanced file uploader */
    .stFileUploader {
        background: linear-gradient(145deg, #ffffff 0%, #f0f4ff 100%) !important;
        border-radius: 15px !important;
        padding: 2rem !important;
        border: 3px dashed #667eea !important;
        text-align: center !important;
    }
    
    .stFileUploader label {
        color: #667eea !important;
        font-weight: 600 !important;
        font-size: 1.1rem !important;
    }
    
    /* Enhanced progress bars */
    .stProgress > div > div > div > div {
        background: linear-gradient(90deg, #667eea, #764ba2) !important;
        border-radius: 15px !important;
        height: 12px !important;
    }
    
    /* Enhanced expander */
    .streamlit-expanderHeader {
        background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%) !important;
        border-radius: 12px !important;
        border: 2px solid rgba(102, 126, 234, 0.2) !important;
        padding: 1rem !important;
    }
    
    /* Compact metrics containers */
    .metric-container {
        background: linear-gradient(145deg, #ffffff 0%, #f0f4ff 100%) !important;
        padding: 1rem 1.5rem !important;
        border-radius: 12px !important;
        text-align: center !important;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1) !important;
        margin: 0.5rem !important;
        border: 2px solid rgba(102, 126, 234, 0.1) !important;
        transition: transform 0.3s ease !important;
        max-height: 120px !important;
        min-height: 100px !important;
    }
    
    .metric-container:hover {
        transform: translateY(-3px) !important;
        box-shadow: 0 8px 20px rgba(0,0,0,0.15) !important;
    }
    
    .metric-container h3 {
        color: #667eea !important;
        font-size: 1.8rem !important;
        font-weight: 800 !important;
        margin: 0 !important;
        line-height: 1.2 !important;
    }
    
    .metric-container p {
        color: #4a5568 !important;
        font-weight: 600 !important;
        margin: 0.3rem 0 0 0 !important;
        font-size: 0.9rem !important;
    }
    
    /* Enhanced skills tags */
    .skill-tag {
        background: linear-gradient(45deg, #667eea, #764ba2) !important;
        color: white !important;
        padding: 0.5rem 1rem !important;
        border-radius: 25px !important;
        margin: 0.3rem !important;
        display: inline-block !important;
        font-size: 0.9rem !important;
        font-weight: 600 !important;
        box-shadow: 0 4px 10px rgba(102, 126, 234, 0.3) !important;
        transition: transform 0.2s ease !important;
    }
    
    .skill-tag:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 6px 15px rgba(102, 126, 234, 0.4) !important;
    }
    
    /* Enhanced animations */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(40px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes slideInLeft {
        from {
            opacity: 0;
            transform: translateX(-50px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.8s ease-out;
    }
    
    .slide-in {
        animation: slideInLeft 0.6s ease-out;
    }
    
    /* Enhanced text styling */
    .highlight-text {
        background: linear-gradient(45deg, #667eea, #764ba2) !important;
        -webkit-background-clip: text !important;
        -webkit-text-fill-color: transparent !important;
        font-weight: 800 !important;
        font-size: 1.2rem !important;
    }
    
    .success-text {
        color: #48bb78 !important;
        font-weight: 700 !important;
    }
    
    .info-text {
        color: #4299e1 !important;
        font-weight: 600 !important;
    }
    
    /* Enhanced chart containers */
    .chart-container {
        background: linear-gradient(145deg, #ffffff 0%, #f7fafc 100%) !important;
        padding: 2rem !important;
        border-radius: 15px !important;
        box-shadow: 0 8px 30px rgba(0,0,0,0.1) !important;
        margin: 1.5rem 0 !important;
        border: 1px solid rgba(102, 126, 234, 0.1) !important;
    }
    
    /* Text area and input styling */
    .stTextArea > div > div > textarea {
        background: linear-gradient(145deg, #ffffff 0%, #f7fafc 100%) !important;
        border: 2px solid rgba(102, 126, 234, 0.2) !important;
        border-radius: 12px !important;
        color: #2d3748 !important;
        font-weight: 500 !important;
    }
    
    /* Sidebar improvements */
    .css-1d391kg .css-1v0mbdj {
        color: white !important;
        font-weight: 600 !important;
    }
    
    /* Streamlit native elements color fixes */
    .stMarkdown, .stText {
        color: #2d3748 !important;
    }
    
    h1, h2, h3, h4, h5, h6 {
        color: #2d3748 !important;
        font-weight: 700 !important;
    }
    
    /* Info boxes */
    .stInfo {
        background: linear-gradient(145deg, #ebf8ff 0%, #bee3f8 100%) !important;
        border: 2px solid #4299e1 !important;
        border-radius: 12px !important;
        color: #2c5282 !important;
    }
    
    .stSuccess {
        background: linear-gradient(145deg, #f0fff4 0%, #c6f6d5 100%) !important;
        border: 2px solid #48bb78 !important;
        border-radius: 12px !important;
        color: #22543d !important;
    }
    
    .stWarning {
        background: linear-gradient(145deg, #fffaf0 0%, #feebc8 100%) !important;
        border: 2px solid #ed8936 !important;
        border-radius: 12px !important;
        color: #9c4221 !important;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'processed_resumes' not in st.session_state:
    st.session_state.processed_resumes = []
if 'bulk_results' not in st.session_state:
    st.session_state.bulk_results = []

class SimpleFileProcessor:
    """Enhanced file processor with better error handling"""
    
    def extract_text(self, uploaded_file):
        """Extract text from uploaded file"""
        try:
            if uploaded_file.name.lower().endswith('.txt'):
                content = uploaded_file.read().decode('utf-8')
                return content
            else:
                st.warning("📝 Please upload a .txt file for this demo. You can copy your resume content into a text file.")
                return None
        except Exception as e:
            st.error(f"❌ Error reading file: {str(e)}")
            return None

class SmartClassifier:
    """Enhanced resume classifier with better analysis"""
    
    def __init__(self):
        self.job_roles = {
            "Software Engineer": ["python", "java", "programming", "software", "development", "coding", "algorithm", "github", "git", "debugging"],
            "Data Scientist": ["machine learning", "python", "statistics", "data analysis", "pandas", "numpy", "ml", "tensorflow", "pytorch", "sklearn"],
            "Frontend Developer": ["javascript", "html", "css", "react", "vue", "angular", "frontend", "ui", "bootstrap", "typescript", "webpack"],
            "Backend Developer": ["api", "database", "server", "backend", "sql", "microservices", "django", "flask", "nodejs", "express", "rest"],
            "Full Stack Developer": ["full stack", "frontend", "backend", "web development", "react", "node.js", "mongodb", "javascript", "python"],
            "Data Analyst": ["excel", "sql", "data analysis", "reporting", "tableau", "power bi", "analytics", "visualization", "business intelligence"],
            "DevOps Engineer": ["docker", "kubernetes", "aws", "azure", "jenkins", "ci/cd", "devops", "cloud", "terraform", "ansible", "monitoring"],
            "Product Manager": ["product management", "roadmap", "stakeholder", "requirements", "agile", "scrum", "strategy", "market research"],
            "UX/UI Designer": ["ux", "ui", "design", "figma", "sketch", "user experience", "wireframe", "prototype", "adobe", "photoshop", "illustrator"],
            "Quality Assurance": ["testing", "qa", "quality assurance", "automation", "selenium", "test cases", "bug", "manual testing", "cypress"],
            "Machine Learning Engineer": ["machine learning", "deep learning", "tensorflow", "pytorch", "ml", "ai", "neural", "nlp", "computer vision"],
            "Project Manager": ["project management", "pmp", "agile", "scrum", "waterfall", "timeline", "coordination", "risk management", "budget"],
            "Cybersecurity Specialist": ["security", "cybersecurity", "penetration testing", "vulnerability", "firewall", "encryption", "network security"],
            "Mobile Developer": ["android", "ios", "mobile", "swift", "kotlin", "react native", "flutter", "mobile app", "app development"]
        }
    
    def classify_resume(self, resume_text):
        """Classify resume with enhanced scoring"""
        text_lower = resume_text.lower()
        role_scores = {}
        
        for role, keywords in self.job_roles.items():
            score = 0
            matched_keywords = []
            
            for keyword in keywords:
                if keyword in text_lower:
                    # Count occurrences and weight by keyword importance
                    occurrences = text_lower.count(keyword)
                    score += occurrences
                    matched_keywords.append(keyword)
            
            # Normalize by number of keywords
            normalized_score = score / len(keywords) if keywords else 0
            role_scores[role] = {
                'score': normalized_score,
                'matched_keywords': matched_keywords
            }
        
        # Sort by score
        sorted_roles = sorted(role_scores.items(), key=lambda x: x[1]['score'], reverse=True)
        
        predictions = []
        max_score = max([data['score'] for data in role_scores.values()]) if role_scores else 1
        
        for role, data in sorted_roles:
            if data['score'] > 0:
                confidence = min(data['score'] / max_score, 1.0) if max_score > 0 else 0
                predictions.append({
                    'role': role,
                    'confidence': confidence,
                    'matched_keywords': data['matched_keywords']
                })
        
        if not predictions:
            predictions = [{'role': 'General Professional', 'confidence': 0.1, 'matched_keywords': []}]
        
        return {
            'method': 'Smart Keyword Analysis',
            'predictions': predictions[:5],
            'top_prediction': predictions[0] if predictions else None
        }

class AdvancedSkillsAnalyzer:
    """Enhanced skills analyzer with categorization"""
    
    def __init__(self):
        self.skill_categories = {
            "Programming Languages": ["python", "java", "javascript", "typescript", "c++", "c#", "ruby", "php", "go", "rust", "swift", "kotlin"],
            "Web Technologies": ["html", "css", "react", "angular", "vue", "django", "flask", "spring", "node.js", "express", "bootstrap", "tailwind"],
            "Databases": ["mysql", "postgresql", "mongodb", "redis", "elasticsearch", "sqlite", "oracle", "cassandra", "dynamodb"],
            "Cloud & DevOps": ["aws", "azure", "gcp", "docker", "kubernetes", "jenkins", "git", "github", "gitlab", "terraform", "ansible"],
            "Data Science & ML": ["machine learning", "deep learning", "ai", "pandas", "numpy", "tensorflow", "pytorch", "sklearn", "tableau", "power bi"],
            "Mobile Development": ["android", "ios", "react native", "flutter", "xamarin", "ionic"],
            "Design & UI/UX": ["figma", "sketch", "photoshop", "illustrator", "adobe", "wireframe", "prototype", "user experience"],
            "Testing & QA": ["selenium", "cypress", "jest", "junit", "testing", "automation", "manual testing", "test cases"],
            "Soft Skills": ["leadership", "communication", "teamwork", "problem solving", "project management", "agile", "scrum"]
        }
        
        # Flatten all skills for general detection
        self.all_skills = []
        for skills in self.skill_categories.values():
            self.all_skills.extend(skills)
    
    def analyze_resume(self, resume_text):
        """Enhanced resume analysis with categorization"""
        text_lower = resume_text.lower()
        
        # Categorized skills extraction
        categorized_skills = {}
        for category, skills in self.skill_categories.items():
            found_skills = []
            for skill in skills:
                if skill in text_lower:
                    found_skills.append(skill.title())
            if found_skills:
                categorized_skills[category] = found_skills
        
        # All skills combined
        all_found_skills = []
        for skills_list in categorized_skills.values():
            all_found_skills.extend(skills_list)
        
        # Experience extraction with better patterns
        experience_patterns = [
            r'(\d+)\s*(?:years?|yrs?)\s*(?:of\s*)?(?:experience|exp)',
            r'(\d+)\+\s*(?:years?|yrs?)',
            r'(\d+)\s*to\s*(\d+)\s*(?:years?|yrs?)',
            r'(\d+)-(\d+)\s*(?:years?|yrs?)'
        ]
        
        experience_years = None
        experience_mentions = []
        
        for pattern in experience_patterns:
            matches = re.finditer(pattern, text_lower)
            for match in matches:
                experience_mentions.append(match.group())
                numbers = re.findall(r'\d+', match.group())
                if numbers:
                    years = max([int(num) for num in numbers])
                    if experience_years is None or years > experience_years:
                        experience_years = years
        
        # Enhanced contact info extraction
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, resume_text)
        
        phone_patterns = [
            r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            r'\(\d{3}\)\s*\d{3}[-.]?\d{4}',
            r'\+\d{1,3}\s*\d{3,4}[-.]?\d{3,4}[-.]?\d{4}'
        ]
        
        phones = []
        for pattern in phone_patterns:
            phones.extend(re.findall(pattern, resume_text))
        
        # LinkedIn profile extraction
        linkedin_pattern = r'linkedin\.com/in/[\w-]+'
        linkedin = re.findall(linkedin_pattern, resume_text, re.IGNORECASE)
        
        # Education extraction
        education_keywords = ['bachelor', 'master', 'phd', 'doctorate', 'degree', 'university', 'college', 'certification']
        education_mentions = []
        for keyword in education_keywords:
            if keyword in text_lower:
                education_mentions.append(keyword)
        
        # Text statistics
        words = resume_text.split()
        sentences = resume_text.split('.')
        
        return {
            'skills': list(set(all_found_skills)),
            'categorized_skills': categorized_skills,
            'experience_years': experience_years,
            'experience_mentions': experience_mentions,
            'contact_info': {
                'email': emails[0] if emails else None,
                'phone': phones[0] if phones else None,
                'linkedin': linkedin[0] if linkedin else None
            },
            'education': education_mentions,
            'text_stats': {
                'word_count': len(words),
                'sentence_count': len(sentences),
                'character_count': len(resume_text),
                'avg_word_length': sum(len(word) for word in words) / len(words) if words else 0
            }
        }

class EnhancedResumeScorer:
    """Enhanced scoring system with detailed breakdown"""
    
    def score_resume(self, resume_text, job_description, classification_result, analysis_result):
        """Calculate comprehensive resume score with detailed breakdown"""
        
        # Skills score (0-35 points)
        skills_count = len(analysis_result.get('skills', []))
        categorized_skills = analysis_result.get('categorized_skills', {})
        skill_diversity = len(categorized_skills)
        
        skills_score = min(skills_count * 2, 25) + min(skill_diversity * 2, 10)
        
        # Experience score (0-25 points)
        experience_years = analysis_result.get('experience_years', 0) or 0
        experience_score = min(experience_years * 2.5, 25)
        
        # Classification confidence score (0-20 points)
        top_prediction = classification_result.get('top_prediction', {})
        confidence_score = (top_prediction.get('confidence', 0) * 20) if top_prediction else 0
        
        # Content quality score (0-10 points)
        word_count = analysis_result['text_stats']['word_count']
        if 300 <= word_count <= 1000:
            content_score = 10
        elif 200 <= word_count < 300 or 1000 < word_count <= 1500:
            content_score = 7
        elif word_count < 200:
            content_score = 3
        else:
            content_score = 5
        
        # Contact and profile completeness (0-10 points)
        contact_info = analysis_result['contact_info']
        profile_score = 0
        if contact_info.get('email'):
            profile_score += 4
        if contact_info.get('phone'):
            profile_score += 3
        if contact_info.get('linkedin'):
            profile_score += 3
        
        overall_score = skills_score + experience_score + confidence_score + content_score + profile_score
        
        return {
            'overall_score': min(overall_score, 100),
            'skills_score': skills_score,
            'experience_score': experience_score,
            'confidence_score': confidence_score,
            'content_score': content_score,
            'profile_score': profile_score,
            'breakdown': self._generate_detailed_breakdown(skills_score, experience_score, confidence_score, content_score, profile_score, analysis_result)
        }
    
    def _generate_detailed_breakdown(self, skills_score, experience_score, confidence_score, content_score, profile_score, analysis_result):
        """Generate detailed breakdown with personalized recommendations"""
        strengths = []
        improvements = []
        recommendations = []
        
        # Analyze strengths
        if skills_score >= 25:
            strengths.append("🎯 Excellent technical skills portfolio")
        elif skills_score >= 15:
            strengths.append("✅ Good technical skills foundation")
        
        if experience_score >= 20:
            strengths.append("💼 Strong professional experience")
        elif experience_score >= 10:
            strengths.append("📈 Solid work background")
        
        if confidence_score >= 15:
            strengths.append("🎪 Clear role alignment and focus")
        
        if profile_score >= 8:
            strengths.append("📞 Complete contact information")
        
        # Identify improvements
        if skills_score < 15:
            improvements.append("🔧 Limited technical skills mentioned")
            recommendations.append("Add more relevant technical skills and certifications")
        
        if experience_score < 10:
            improvements.append("⏱️ Insufficient experience details")
            recommendations.append("Include specific achievements with quantifiable results")
        
        if confidence_score < 10:
            improvements.append("🎯 Unclear role targeting")
            recommendations.append("Tailor resume more specifically to target role")
        
        if content_score < 7:
            improvements.append("📝 Content length needs optimization")
            recommendations.append("Optimize resume length (300-1000 words ideal)")
        
        if profile_score < 7:
            improvements.append("📧 Incomplete contact information")
            recommendations.append("Add missing contact details (email, phone, LinkedIn)")
        
        return {
            'strengths': strengths,
            'improvements': improvements,
            'recommendations': recommendations
        }

def process_resume(uploaded_file, job_description=""):
    """Process resume with enhanced analysis"""
    file_processor = SimpleFileProcessor()
    classifier = SmartClassifier()
    analyzer = AdvancedSkillsAnalyzer()
    scorer = EnhancedResumeScorer()
    
    with st.spinner("🔄 Processing resume..."):
        text_content = file_processor.extract_text(uploaded_file)
        
        if not text_content:
            return None
        
        # Perform analysis
        classification_result = classifier.classify_resume(text_content)
        analysis_result = analyzer.analyze_resume(text_content)
        score_result = scorer.score_resume(text_content, job_description, classification_result, analysis_result)
        
        result = {
            'filename': uploaded_file.name,
            'text_content': text_content,
            'classification': classification_result,
            'analysis': analysis_result,
            'score': score_result,
            'processed_at': datetime.now().isoformat()
        }
        
        return result

def main():
    # Header with custom styling
    st.markdown("""
    <div class="main-header fade-in">
        <h1>🤖 AI-Powered Resume Screening System</h1>
        <p>Intelligent resume analysis with advanced NLP and machine learning algorithms</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar navigation with styling
    st.sidebar.markdown("### 🧭 Navigation")
    page = st.sidebar.selectbox(
        "Choose a feature:",
        ["🔍 Single Resume Analysis", "📁 Bulk Processing", "📊 Analytics Dashboard", "💡 Tips & Guide"]
    )
    
    if page == "🔍 Single Resume Analysis":
        single_resume_page()
    elif page == "📁 Bulk Processing":
        bulk_processing_page()
    elif page == "📊 Analytics Dashboard":
        analytics_page()
    elif page == "💡 Tips & Guide":
        tips_page()

def single_resume_page():
    st.markdown('<div class="fade-in">', unsafe_allow_html=True)
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("### 📄 Single Resume Analysis")
        
        # Job description input with styling
        st.markdown("#### 💼 Job Requirements (Optional)")
        job_description = st.text_area(
            "Enter job description to improve matching accuracy:",
            height=120,
            placeholder="Example: Looking for a Python developer with 3+ years experience in web development, Django, React, and cloud platforms...",
            help="Adding a job description helps improve role matching and scoring accuracy"
        )
        
        # File upload with custom styling
        st.markdown("#### 📤 Upload Resume")
        uploaded_file = st.file_uploader(
            "Choose your resume file",
            type=['txt'],
            help="📝 Please upload a .txt file. Copy your resume content into a text file for analysis."
        )
        
        if uploaded_file is not None:
            st.markdown(f"""
            <div class="metric-card">
                <h4>📁 File Information</h4>
                <p><strong>Name:</strong> {uploaded_file.name}</p>
                <p><strong>Size:</strong> {uploaded_file.size} bytes</p>
                <p><strong>Type:</strong> Text Document</p>
            </div>
            """, unsafe_allow_html=True)
            
            if st.button("🚀 Analyze Resume", type="primary"):
                result = process_resume(uploaded_file, job_description)
                
                if result:
                    st.session_state.processed_resumes.append(result)
                    st.success("✅ Resume analysis completed successfully!")
                    display_enhanced_results(result)
    
    with col2:
        st.markdown("### 📈 Quick Stats")
        
        total_processed = len(st.session_state.processed_resumes)
        
        st.markdown(f"""
        <div class="metric-container">
            <h3>{total_processed}</h3>
            <p>Resumes Analyzed</p>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.processed_resumes:
            avg_score = sum(r['score']['overall_score'] for r in st.session_state.processed_resumes) / len(st.session_state.processed_resumes)
            
            st.markdown(f"""
            <div class="metric-container">
                <h3>{avg_score:.1f}</h3>
                <p>Average Score</p>
            </div>
            """, unsafe_allow_html=True)
        
        # Recent results
        if st.session_state.processed_resumes:
            st.markdown("### 📋 Recent Analysis")
            for result in reversed(st.session_state.processed_resumes[-3:]):
                score = result['score']['overall_score']
                color = "#4CAF50" if score >= 70 else "#FF9800" if score >= 50 else "#F44336"
                
                st.markdown(f"""
                <div style="background: rgba(255,255,255,0.9); padding: 1rem; border-radius: 8px; margin: 0.5rem 0; border-left: 4px solid {color};">
                    <strong>{result['filename']}</strong><br>
                    <span style="color: {color}; font-weight: 600;">Score: {score:.1f}/100</span>
                </div>
                """, unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)

def display_enhanced_results(result, compact=False):
    """Display enhanced results with beautiful styling"""
    
    st.markdown("---")
    st.markdown("## 📊 Analysis Results")
    
    # Score overview
    score = result['score']['overall_score']
    classification = result['classification']
    analysis = result['analysis']
    
    # Main score display
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        score_color = "#4CAF50" if score >= 70 else "#FF9800" if score >= 50 else "#F44336"
        
        st.markdown(f"""
        <div class="score-card">
            <h2>Overall Score</h2>
            <h1 style="font-size: 3rem; margin: 1rem 0;">{score:.1f}/100</h1>
            <p style="font-size: 1.2rem;">
                {'🌟 Excellent' if score >= 80 else '✅ Good' if score >= 60 else '📈 Needs Improvement'}
            </p>
        </div>
        """, unsafe_allow_html=True)
    
    # Detailed breakdown with proper spacing
    st.markdown("### 📈 Score Breakdown")
    st.markdown("<br>", unsafe_allow_html=True)
    
    score_data = result['score']
    breakdown_cols = st.columns(5)
    
    score_items = [
        ("🔧 Skills", score_data.get('skills_score', 0), 35),
        ("💼 Experience", score_data.get('experience_score', 0), 25),
        ("🎯 Role Match", score_data.get('confidence_score', 0), 20),
        ("📝 Content", score_data.get('content_score', 0), 10),
        ("📞 Profile", score_data.get('profile_score', 0), 10)
    ]
    
    for i, (label, value, max_val) in enumerate(score_items):
        with breakdown_cols[i]:
            percentage = (value / max_val) * 100 if max_val > 0 else 0
            color = "#4CAF50" if percentage >= 70 else "#FF9800" if percentage >= 50 else "#F44336"
            
            st.markdown(f"""
            <div style="
                background: linear-gradient(145deg, #ffffff 0%, #f0f4ff 100%);
                padding: 1rem;
                border-radius: 12px;
                text-align: center;
                box-shadow: 0 4px 15px rgba(0,0,0,0.1);
                margin: 0.5rem 0.2rem;
                border: 2px solid rgba(102, 126, 234, 0.1);
                height: 150px;
                display: flex;
                flex-direction: column;
                justify-content: space-evenly;
                align-items: center;
            ">
                <h5 style="
                    color: #667eea; 
                    margin: 0; 
                    font-size: 0.9rem; 
                    font-weight: 600;
                    height: 20px;
                    display: flex;
                    align-items: center;
                ">{label}</h5>
                <h3 style="
                    color: {color}; 
                    margin: 0; 
                    font-size: 1.4rem; 
                    font-weight: 800;
                    height: 35px;
                    display: flex;
                    align-items: center;
                    line-height: 1;
                ">{value:.1f}/{max_val}</h3>
                <div style="
                    background: #f0f0f0; 
                    border-radius: 10px; 
                    height: 8px; 
                    width: 90%;
                    margin: 0;
                ">
                    <div style="
                        background: {color}; 
                        width: {percentage}%; 
                        height: 100%; 
                        border-radius: 10px; 
                        transition: width 0.3s ease;
                    "></div>
                </div>
            </div>
            """, unsafe_allow_html=True)
    
    # Classification and Skills
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div class="analysis-card">
            <h3>🎯 Role Classification</h3>
        """, unsafe_allow_html=True)
        
        top_role = classification['predictions'][0] if classification['predictions'] else {'role': 'Unknown', 'confidence': 0}
        
        st.markdown(f"""
            <div style="text-align: center; margin: 1rem 0;">
                <h2 style="color: #4CAF50; margin: 0;">{top_role['role']}</h2>
                <p style="font-size: 1.1rem; margin: 0.5rem 0;">
                    Confidence: <strong>{top_role['confidence']:.1%}</strong>
                </p>
            </div>
        """, unsafe_allow_html=True)
        
        if len(classification['predictions']) > 1:
            st.markdown("**Other Possible Roles:**")
            for pred in classification['predictions'][1:4]:
                st.markdown(f"• {pred['role']}: {pred['confidence']:.1%}")
        
        st.markdown("</div>", unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="skills-card">
            <h3>🔧 Technical Skills</h3>
        """, unsafe_allow_html=True)
        
        categorized_skills = analysis.get('categorized_skills', {})
        
        if categorized_skills:
            for category, skills in list(categorized_skills.items())[:3]:  # Show top 3 categories
                st.markdown(f"**{category}:**")
                skills_html = ""
                for skill in skills[:6]:  # Show max 6 skills per category
                    skills_html += f'<span class="skill-tag">{skill}</span> '
                st.markdown(skills_html, unsafe_allow_html=True)
                st.markdown("")
        else:
            st.markdown("No categorized skills detected.")
        
        st.markdown("</div>", unsafe_allow_html=True)
    
    # Experience and Contact Info
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 💼 Experience Analysis")
        
        exp_years = analysis.get('experience_years')
        if exp_years:
            st.markdown(f"""
            <div class="metric-card">
                <h3 style="color: #4CAF50; text-align: center;">{exp_years} Years</h3>
                <p style="text-align: center;">Professional Experience</p>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.info("📝 No specific experience years mentioned")
        
        # Experience mentions
        exp_mentions = analysis.get('experience_mentions', [])
        if exp_mentions:
            st.markdown("**Experience Mentions:**")
            for mention in exp_mentions[:3]:
                st.markdown(f"• {mention}")
    
    with col2:
        st.markdown("### 📞 Contact Information")
        
        contact_info = analysis['contact_info']
        
        contact_items = [
            ("📧 Email", contact_info.get('email')),
            ("📱 Phone", contact_info.get('phone')),
            ("🔗 LinkedIn", contact_info.get('linkedin'))
        ]
        
        for icon_label, value in contact_items:
            if value:
                st.markdown(f"✅ **{icon_label}:** {value}")
            else:
                st.markdown(f"❌ **{icon_label}:** Not provided")
    
    # Recommendations
    breakdown = score_data.get('breakdown', {})
    
    if breakdown.get('strengths') or breakdown.get('recommendations'):
        st.markdown("### 💡 AI Insights & Recommendations")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if breakdown.get('strengths'):
                st.markdown("#### ✨ Strengths")
                for strength in breakdown['strengths']:
                    st.markdown(f"• {strength}")
        
        with col2:
            if breakdown.get('recommendations'):
                st.markdown("#### 🚀 Recommendations")
                for rec in breakdown['recommendations']:
                    st.markdown(f"• {rec}")

def bulk_processing_page():
    st.markdown('<div class="fade-in">', unsafe_allow_html=True)
    
    st.markdown("### 📁 Bulk Resume Processing")
    st.markdown("Upload multiple resumes for comprehensive batch analysis and comparison.")
    
    # Job description input
    st.markdown("#### 💼 Job Description (Recommended)")
    job_description = st.text_area(
        "Enter job requirements for better matching across all resumes:",
        height=100,
        placeholder="Enter detailed job requirements, skills, and qualifications..."
    )
    
    # Bulk file upload
    st.markdown("#### 📤 Upload Multiple Resumes")
    uploaded_files = st.file_uploader(
        "Choose multiple resume files",
        type=['txt'],
        accept_multiple_files=True,
        help="Upload multiple .txt files for batch processing"
    )
    
    if uploaded_files:
        st.markdown(f"""
        <div class="metric-card">
            <h4>📊 Upload Summary</h4>
            <p><strong>Files Selected:</strong> {len(uploaded_files)}</p>
            <p><strong>Total Size:</strong> {sum(f.size for f in uploaded_files)} bytes</p>
        </div>
        """, unsafe_allow_html=True)
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🚀 Process All Resumes", type="primary"):
                process_bulk_resumes(uploaded_files, job_description)
        
        with col2:
            if st.button("🗑️ Clear Previous Results"):
                st.session_state.bulk_results = []
                st.success("✅ Previous results cleared!")
                st.rerun()
        
        # Display bulk results if available
        if st.session_state.bulk_results:
            display_bulk_results()
    
    st.markdown('</div>', unsafe_allow_html=True)

def process_bulk_resumes(uploaded_files, job_description):
    """Process multiple resumes with progress tracking"""
    
    results = []
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    for i, uploaded_file in enumerate(uploaded_files):
        status_text.text(f"🔄 Processing {uploaded_file.name}... ({i+1}/{len(uploaded_files)})")
        progress_bar.progress((i + 1) / len(uploaded_files))
        
        result = process_resume(uploaded_file, job_description)
        if result:
            results.append(result)
    
    status_text.text("✅ Processing complete!")
    
    # Store and rank results
    st.session_state.bulk_results = sorted(results, key=lambda x: x['score']['overall_score'], reverse=True)
    
    # Add ranking
    for i, result in enumerate(st.session_state.bulk_results):
        result['rank'] = i + 1
    
    st.success(f"🎉 Successfully processed {len(results)} out of {len(uploaded_files)} resumes!")

def display_bulk_results():
    """Display bulk processing results with enhanced visualizations"""
    
    results = st.session_state.bulk_results
    
    if not results:
        st.warning("No results to display")
        return
    
    st.markdown("---")
    st.markdown("## 📊 Bulk Analysis Results")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="metric-container">
            <h3>{len(results)}</h3>
            <p>Total Resumes</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        avg_score = sum(r['score']['overall_score'] for r in results) / len(results)
        st.markdown(f"""
        <div class="metric-container">
            <h3>{avg_score:.1f}</h3>
            <p>Average Score</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        top_score = max(r['score']['overall_score'] for r in results)
        st.markdown(f"""
        <div class="metric-container">
            <h3>{top_score:.1f}</h3>
            <p>Highest Score</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        qualified = sum(1 for r in results if r['score']['overall_score'] >= 70)
        st.markdown(f"""
        <div class="metric-container">
            <h3>{qualified}</h3>
            <p>Qualified (70+)</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Top candidates
    st.markdown("### 🏆 Top Candidates")
    
    for i, result in enumerate(results[:5]):
        score = result['score']['overall_score']
        top_role = result['classification']['predictions'][0]['role'] if result['classification']['predictions'] else 'Unknown'
        skills_count = len(result['analysis'].get('skills', []))
        
        score_color = "#4CAF50" if score >= 70 else "#FF9800" if score >= 50 else "#F44336"
        
        with st.expander(f"#{i+1} {result['filename']} - Score: {score:.1f}"):
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.markdown(f"**Role:** {top_role}")
                st.markdown(f"**Score:** {score:.1f}/100")
            
            with col2:
                st.markdown(f"**Skills:** {skills_count} detected")
                exp_years = result['analysis'].get('experience_years')
                st.markdown(f"**Experience:** {exp_years or 'Not specified'} years")
            
            with col3:
                email = result['analysis']['contact_info'].get('email', 'Not provided')
                st.markdown(f"**Email:** {email}")
                phone = result['analysis']['contact_info'].get('phone', 'Not provided')
                st.markdown(f"**Phone:** {phone}")

def analytics_page():
    """Enhanced analytics dashboard"""
    
    st.markdown('<div class="fade-in">', unsafe_allow_html=True)
    
    if st.session_state.bulk_results:
        results = st.session_state.bulk_results
    elif st.session_state.processed_resumes:
        results = st.session_state.processed_resumes
    else:
        st.markdown("""
        <div class="metric-card" style="text-align: center; padding: 3rem;">
            <h2>📊 Analytics Dashboard</h2>
            <p>No data available yet. Process some resumes to see analytics!</p>
            <p>💡 Upload resumes in Single Analysis or Bulk Processing to generate insights.</p>
        </div>
        """, unsafe_allow_html=True)
        return
    
    st.markdown("### 📊 Resume Analytics Dashboard")
    
    # Key metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        avg_score = sum(r['score']['overall_score'] for r in results) / len(results)
        st.markdown(f"""
        <div class="metric-container">
            <h3>{avg_score:.1f}</h3>
            <p>Average Score</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        all_skills = []
        for r in results:
            all_skills.extend(r['analysis'].get('skills', []))
        unique_skills = len(set(all_skills))
        st.markdown(f"""
        <div class="metric-container">
            <h3>{unique_skills}</h3>
            <p>Unique Skills</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        avg_exp = []
        for r in results:
            exp = r['analysis'].get('experience_years')
            if exp:
                avg_exp.append(exp)
        avg_exp_years = sum(avg_exp) / len(avg_exp) if avg_exp else 0
        st.markdown(f"""
        <div class="metric-container">
            <h3>{avg_exp_years:.1f}</h3>
            <p>Avg Experience</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        roles = [r['classification']['predictions'][0]['role'] for r in results if r['classification']['predictions']]
        most_common = Counter(roles).most_common(1)[0] if roles else ("N/A", 0)
        st.markdown(f"""
        <div class="metric-container">
            <h3>{most_common[1]}</h3>
            <p>{most_common[0][:15]}...</p>
        </div>
        """, unsafe_allow_html=True)
    
    # Skills analysis
    if all_skills:
        st.markdown("### 🔧 Most In-Demand Skills")
        
        skill_counts = Counter(all_skills)
        top_skills = skill_counts.most_common(10)
        
        # Create a simple chart display
        st.markdown('<div class="chart-container">', unsafe_allow_html=True)
        
        for skill, count in top_skills:
            percentage = (count / max([c for _, c in top_skills])) * 100
            st.markdown(f"**{skill}:** {count} mentions")
            st.progress(percentage / 100)
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Score distribution
    st.markdown("### 📈 Score Distribution")
    
    scores = [r['score']['overall_score'] for r in results]
    
    # Create score ranges
    score_ranges = {
        'Excellent (80-100)': len([s for s in scores if s >= 80]),
        'Good (60-79)': len([s for s in scores if 60 <= s < 80]),
        'Average (40-59)': len([s for s in scores if 40 <= s < 60]),
        'Below Average (0-39)': len([s for s in scores if s < 40])
    }
    
    st.markdown('<div class="chart-container">', unsafe_allow_html=True)
    
    for range_name, count in score_ranges.items():
        if count > 0:
            percentage = (count / len(scores)) * 100
            st.markdown(f"**{range_name}:** {count} candidates ({percentage:.1f}%)")
            st.progress(percentage / 100)
    
    st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)

def tips_page():
    """Tips and guide page"""
    
    st.markdown('<div class="fade-in">', unsafe_allow_html=True)
    
    st.markdown("### 💡 Resume Optimization Tips & Guide")
    
    st.markdown("""
    <div class="metric-card">
        <h3>🎯 How to Get a High Score</h3>
        <p>Our AI system evaluates resumes based on several key factors:</p>
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div class="skills-card">
            <h4>🔧 Technical Skills (35 points)</h4>
            <ul>
                <li>Include relevant programming languages</li>
                <li>Mention frameworks and tools</li>
                <li>Add certifications and technologies</li>
                <li>Show skill diversity across categories</li>
            </ul>
        </div>
        
        <div class="analysis-card">
            <h4>💼 Experience (25 points)</h4>
            <ul>
                <li>Clearly state years of experience</li>
                <li>Use action words (developed, led, managed)</li>
                <li>Include specific achievements</li>
                <li>Quantify your results when possible</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="skills-card">
            <h4>🎯 Role Alignment (20 points)</h4>
            <ul>
                <li>Tailor resume to specific job roles</li>
                <li>Use industry-specific keywords</li>
                <li>Highlight relevant experiences</li>
                <li>Match job description requirements</li>
            </ul>
        </div>
        
        <div class="analysis-card">
            <h4>📞 Profile Completeness (10 points)</h4>
            <ul>
                <li>Include professional email address</li>
                <li>Add phone number</li>
                <li>Provide LinkedIn profile</li>
                <li>Ensure contact info is accurate</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("""
    <div class="metric-card">
        <h3>📝 Content Guidelines</h3>
        <ul>
            <li><strong>Optimal Length:</strong> 300-1000 words for best scoring</li>
            <li><strong>Structure:</strong> Clear sections for experience, skills, education</li>
            <li><strong>Keywords:</strong> Include relevant industry terms</li>
            <li><strong>Format:</strong> Use consistent formatting and clear language</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("""
    <div class="score-card" style="margin-top: 2rem;">
        <h3>🚀 Pro Tips for Maximum Impact</h3>
        <p>• Use specific technologies and tools relevant to your field</p>
        <p>• Include measurable achievements and project outcomes</p>
        <p>• Keep content concise but comprehensive</p>
        <p>• Update regularly with new skills and experiences</p>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown('</div>', unsafe_allow_html=True)

if __name__ == "__main__":
    main()