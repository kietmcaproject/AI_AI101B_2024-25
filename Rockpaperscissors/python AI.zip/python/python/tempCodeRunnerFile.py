import pygame
import random

# Initialize pygame
pygame.init()

# Colors
DARK_ORANGE = (255, 140, 0)  # Dark Orange Background
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)  # RED for "You Win!" and "You Lose!"
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)  # BLUE for "It's a Draw!"

# Screen settings
WIDTH, HEIGHT = 1000, 600  # Increased width for history section
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Rock Paper Scissors - Ultimate Edition")

# Load images
rock_img = pygame.image.load("rock.png")
paper_img = pygame.image.load("paper.png")
scissors_img = pygame.image.load("scissors.png")

# Resize images
img_size = (150, 150)
rock_img = pygame.transform.scale(rock_img, img_size)
paper_img = pygame.transform.scale(paper_img, img_size)
scissors_img = pygame.transform.scale(scissors_img, img_size)

# Function to add a black border to images
def add_border(image, border_color=BLACK, border_width=5):
    bordered_img = pygame.Surface((img_size[0] + 2 * border_width, img_size[1] + 2 * border_width))
    bordered_img.fill(border_color)
    bordered_img.blit(image, (border_width, border_width))
    return bordered_img

# Apply black border to images
rock_img = add_border(rock_img)
paper_img = add_border(paper_img)
scissors_img = add_border(scissors_img)

# Font settings
font_large = pygame.font.Font(None, 60)
font_medium = pygame.font.Font(None, 40)
font_small = pygame.font.Font(None, 28)

# Game variables
score_player = 0
score_computer = 0
choices = ["rock", "paper", "scissors"]
player_choice = ""
computer_choice = ""
result_text = ""
result_color = YELLOW  # Default color for result text
history = []  # List to store history of last 5 rounds

running = True
while running:
    screen.fill(DARK_ORANGE)  # Background color changed to DARK ORANGE
    
    # Heading
    heading_text = font_large.render("Rock Paper Scissors!", True, BLACK)
    screen.blit(heading_text, (WIDTH // 3, 20))
    
    # Score Display (Color is BLACK)
    score_text = font_medium.render(f"Score - You: {score_player} | Computer: {score_computer}", True, BLACK)
    screen.blit(score_text, (WIDTH // 3, 80))
    
    # Display Choices with Black Border
    screen.blit(rock_img, (100, 200))
    screen.blit(paper_img, (325, 200))
    screen.blit(scissors_img, (550, 200))
    
    # Display 'You Choose' and 'Computer Choose'
    player_text = font_medium.render("You Choose:", True, BLACK)
    screen.blit(player_text, (100, 400))
    choice_text = font_medium.render(player_choice, True, YELLOW)
    screen.blit(choice_text, (280, 400))
    
    computer_text = font_medium.render("Computer Choose:", True, BLACK)
    screen.blit(computer_text, (100, 450))
    comp_choice_text = font_medium.render(computer_choice, True, YELLOW)
    screen.blit(comp_choice_text, (380, 450))
    
    # Display Result
    result_display = font_large.render(result_text, True, result_color)
    screen.blit(result_display, (WIDTH // 3, 500))
    
    # Draw history box
    pygame.draw.rect(screen, BLACK, (800, 50, 180, 500), 5)  # Black border for history section
    history_title = font_medium.render("History", True, BLACK)
    screen.blit(history_title, (850, 60))

    # Display last 5 rounds in history (in 2-line format)
    y_offset = 100
    for round_result in history[-5:]:  # Show only last 5 rounds
        # Split round_result into two lines for player and computer
        player_line = font_small.render(f"You: {round_result[0]}", True, BLACK)
        computer_line = font_small.render(f"Computer: {round_result[1]}", True, BLACK)
        
        screen.blit(player_line, (810, y_offset))
        screen.blit(computer_line, (810, y_offset + 20))
        
        y_offset += 40  # Adjust spacing for compact display

    pygame.display.flip()
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            if 100 <= x <= 250 and 200 <= y <= 350:
                player_choice = "rock"
            elif 325 <= x <= 475 and 200 <= y <= 350:
                player_choice = "paper"
            elif 550 <= x <= 700 and 200 <= y <= 350:
                player_choice = "scissors"
            
            if player_choice:
                computer_choice = random.choice(choices)
                if player_choice == computer_choice:
                    result_text = "It's a Draw!"
                    result_color = BLUE  # BLUE for "It's a Draw!"
                    history.append((player_choice, computer_choice))  # Add to history as tuple
                elif (player_choice == "rock" and computer_choice == "scissors") or \
                     (player_choice == "paper" and computer_choice == "rock") or \
                     (player_choice == "scissors" and computer_choice == "paper"):
                    result_text = "You Win!"
                    result_color = RED  # RED for "You Win!"
                    score_player += 1
                    history.append((player_choice, computer_choice))  # Add to history as tuple
                else:
                    result_text = "You Lose!"
                    result_color = RED  # RED for "You Lose!"
                    score_computer += 1
                    history.append((player_choice, computer_choice))  # Add to history as tuple

pygame.quit()
