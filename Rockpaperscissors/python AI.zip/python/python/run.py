    cd C:\Users\chauh\Downloads\python\python\
   python rock_paper_scissors.py
