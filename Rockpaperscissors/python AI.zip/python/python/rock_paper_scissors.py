import pygame
import random
import sys

# Initialize pygame and the mixer for sound
pygame.init()
pygame.mixer.init()

# Load sound files
win_sound = pygame.mixer.Sound("win.wav")
lose_sound = pygame.mixer.Sound("lose.wav")
draw_sound = pygame.mixer.Sound("draw.wav")

# Colors
DARK_ORANGE = (255, 140, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
LIGHT_GRAY = (220, 220, 220)

# Screen settings
WIDTH, HEIGHT = 1000, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Rock Paper Scissors - Ultimate Edition")

# Load images
rock_img = pygame.image.load("rock.png")
paper_img = pygame.image.load("paper.png")
scissors_img = pygame.image.load("scissors.png")

# Resize images
img_size = (150, 150)
rock_img = pygame.transform.scale(rock_img, img_size)
paper_img = pygame.transform.scale(paper_img, img_size)
scissors_img = pygame.transform.scale(scissors_img, img_size)

def add_border(image, border_color=BLACK, border_width=5):
    bordered_img = pygame.Surface((img_size[0] + 2 * border_width, img_size[1] + 2 * border_width))
    bordered_img.fill(border_color)
    bordered_img.blit(image, (border_width, border_width))
    return bordered_img

# Add border to images
rock_img = add_border(rock_img)
paper_img = add_border(paper_img)
scissors_img = add_border(scissors_img)

# Fonts
font_large = pygame.font.Font(None, 60)
font_medium = pygame.font.Font(None, 40)
font_small = pygame.font.Font(None, 28)

# Game variables
score_player = 0
score_computer = 0
choices = ["rock", "paper", "scissors"]
player_choice = ""
computer_choice = ""
result_text = ""
result_color = YELLOW
history = []

# ✅ Buttons
reset_button = pygame.Rect(820, 10, 150, 40)
quit_button = pygame.Rect(820, 60, 150, 40)

running = True
while running:
    screen.fill(DARK_ORANGE)

    heading_text = font_large.render("Rock Paper Scissors!", True, BLACK)
    screen.blit(heading_text, (WIDTH // 3, 20))

    score_text = font_medium.render(f"Score - You: {score_player} | Computer: {score_computer}", True, BLACK)
    screen.blit(score_text, (WIDTH // 3, 80))

    screen.blit(rock_img, (100, 200))
    screen.blit(paper_img, (325, 200))
    screen.blit(scissors_img, (550, 200))

    player_text = font_medium.render("You Choose:", True, BLACK)
    screen.blit(player_text, (100, 400))
    choice_text = font_medium.render(player_choice, True, YELLOW)
    screen.blit(choice_text, (280, 400))

    computer_text = font_medium.render("Computer Choose:", True, BLACK)
    screen.blit(computer_text, (100, 450))
    comp_choice_text = font_medium.render(computer_choice, True, YELLOW)
    screen.blit(comp_choice_text, (380, 450))

    result_display = font_large.render(result_text, True, result_color)
    screen.blit(result_display, (WIDTH // 3, 500))

    # History Box
    pygame.draw.rect(screen, BLACK, (800, 120, 180, 430), 5)
    history_title = font_medium.render("History", True, BLACK)
    screen.blit(history_title, (850, 130))

    y_offset = 170
    for round_result in history[-5:]:
        player_line = font_small.render(f"You: {round_result[0]}", True, BLACK)
        computer_line = font_small.render(f"Computer: {round_result[1]}", True, BLACK)
        screen.blit(player_line, (810, y_offset))
        screen.blit(computer_line, (810, y_offset + 20))
        y_offset += 40

    # ✅ Draw Reset and Quit Buttons
    pygame.draw.rect(screen, LIGHT_GRAY, reset_button)
    pygame.draw.rect(screen, LIGHT_GRAY, quit_button)
    screen.blit(font_small.render("Reset Game", True, BLACK), (reset_button.x + 20, reset_button.y + 10))
    screen.blit(font_small.render("Quit Game", True, BLACK), (quit_button.x + 30, quit_button.y + 10))

    pygame.display.flip()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos

            # ✅ Button Click Handling
            if reset_button.collidepoint(event.pos):
                score_player = 0
                score_computer = 0
                player_choice = ""
                computer_choice = ""
                result_text = ""
                history.clear()

            elif quit_button.collidepoint(event.pos):
                pygame.quit()
                sys.exit()

            # Choice click handling
            if 100 <= x <= 250 and 200 <= y <= 350:
                player_choice = "rock"
            elif 325 <= x <= 475 and 200 <= y <= 350:
                player_choice = "paper"
            elif 550 <= x <= 700 and 200 <= y <= 350:
                player_choice = "scissors"
            else:
                continue

            computer_choice = random.choice(choices)

            if player_choice == computer_choice:
                result_text = "It's a Draw!"
                result_color = BLUE
                draw_sound.play()
            elif (player_choice == "rock" and computer_choice == "scissors") or \
                 (player_choice == "paper" and computer_choice == "rock") or \
                 (player_choice == "scissors" and computer_choice == "paper"):
                result_text = "You Win!"
                result_color = GREEN
                win_sound.play()
                score_player += 1
            else:
                result_text = "You Lose!"
                result_color = RED
                lose_sound.play()
                score_computer += 1

            history.append((player_choice, computer_choice))
            if len(history) > 5:
                history.pop(0)



