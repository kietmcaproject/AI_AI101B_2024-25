import pygame
import random
import os
import time

# Initialize pygame
pygame.init()
pygame.mixer.init()

# Game settings
GRID_SIZE = 4  # 4x4 grid
TILE_SIZE = 600 // GRID_SIZE
IMAGE_PATH = "puzzle_image.jpg"
SOUND_PATH = "move.wav"
MUSIC_PATH = "background.mp3"

# Load image
original_image = pygame.image.load(IMAGE_PATH)
image = pygame.transform.scale(original_image, (600, 600))
reference_image = pygame.transform.scale(original_image, (300, 300))

# Load move sound
move_sound = pygame.mixer.Sound(SOUND_PATH) if os.path.exists(SOUND_PATH) else None

# Load background music
if os.path.exists(MUSIC_PATH):
    pygame.mixer.music.load(MUSIC_PATH)
    pygame.mixer.music.play(-1)  # Loop music infinitely

# Timer & Moves
start_time = time.time()
moves = 0

# Create tiles
tiles = []
tile_map = {}
tile_positions = [(x, y) for y in range(GRID_SIZE) for x in range(GRID_SIZE)]

for i, (x, y) in enumerate(tile_positions[:-1]):
    rect = pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
    tile_image = image.subsurface(rect).copy()
    tiles.append((tile_image, (x, y)))
    tile_map[(x, y)] = i

empty_tile = tile_positions[-1]
tiles.append((None, empty_tile))
tile_map[empty_tile] = len(tiles) - 1

# Shuffle Function (Ensures solvability)
def shuffle_tiles():
    global tiles, empty_tile
    positions = [tile[1] for tile in tiles]
    random.shuffle(positions)
    while not is_solvable(positions):
        random.shuffle(positions)
    for i, pos in enumerate(positions):
        tiles[i] = (tiles[i][0], pos)
    empty_tile = positions[-1]

def is_solvable(positions):
    inversion_count = 0
    flat_list = [pos for pos in positions if pos != empty_tile]
    for i in range(len(flat_list)):
        for j in range(i + 1, len(flat_list)):
            if flat_list[i] > flat_list[j]:
                inversion_count += 1
    return inversion_count % 2 == 0 if GRID_SIZE % 2 == 1 else (inversion_count + GRID_SIZE - empty_tile[1]) % 2 == 0

shuffle_tiles()

# Initialize screen
screen = pygame.display.set_mode((1000, 600))
pygame.display.set_caption("Super Smart Puzzle")

# Draw Function
def draw_tiles():
    screen.fill((30, 30, 30))
    pygame.draw.rect(screen, (150, 150, 150), (650, 100, 320, 320), border_radius=20)
    screen.blit(reference_image, (660, 110))
    pygame.draw.rect(screen, (255, 255, 255), (660, 110, 300, 300), 3)

    for tile, pos in tiles:
        if tile:
            screen.blit(tile, (pos[0] * TILE_SIZE, pos[1] * TILE_SIZE))

    # Timer and Moves Counter
    font = pygame.font.Font(None, 36)
    elapsed_time = round(time.time() - start_time)
    text = font.render(f"Time: {elapsed_time}s  Moves: {moves}", True, (255, 255, 255))
    screen.blit(text, (660, 450))

    # Winning Message
    if is_solved():
        font = pygame.font.Font(None, 50)
        win_text = font.render("🎉 Puzzle Solved! 🎉", True, (0, 255, 0))
        screen.blit(win_text, (660, 500))

    pygame.display.flip()

# Check Winning Condition
def is_solved():
    for i, (tile, pos) in enumerate(tiles):
        if pos != tile_positions[i]:
            return False
    return True

# Get adjacent tiles
def get_adjacent_tiles():
    x, y = empty_tile
    moves = [(x-1, y), (x+1, y), (x, y-1), (x, y+1)]
    return [pos for pos in moves if 0 <= pos[0] < GRID_SIZE and 0 <= pos[1] < GRID_SIZE]

# Move tile function
def move_tile(clicked_tile):
    global empty_tile, moves
    for i, (_, pos) in enumerate(tiles):
        if pos == clicked_tile:
            tiles[i] = (tiles[i][0], empty_tile)
            empty_tile = clicked_tile
            moves += 1
            if move_sound:
                move_sound.play()
            break

# Hint System
def get_hint():
    for i, (tile, pos) in enumerate(tiles):
        if pos != tile_positions[i] and tile is not None:
            return pos  # Returns a wrong tile position for hint
    return None

# Game loop
running = True
while running:
    draw_tiles()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            if 660 <= mouse_x <= 960 and 500 <= mouse_y <= 540:  # Hint button
                hint_tile = get_hint()
                if hint_tile:
                    pygame.draw.rect(screen, (255, 0, 0), (hint_tile[0] * TILE_SIZE, hint_tile[1] * TILE_SIZE, TILE_SIZE, TILE_SIZE), 5)
                    pygame.display.flip()
                    pygame.time.delay(500)
            elif mouse_x < 600:
                clicked_tile = (mouse_x // TILE_SIZE, mouse_y // TILE_SIZE)
                if clicked_tile in get_adjacent_tiles():
                    move_tile(clicked_tile)

pygame.quit()
